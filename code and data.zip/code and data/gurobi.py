# -*- coding: utf-8 -*-
"""
Created on Sun Oct  5 16:16:21 2025

@author: 孙潍霖
"""

import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import json
import random
from gendata import calculate_total_shortage, calculate_fixed_purchase_cost, weekly_demand_mean

def read_demand_scenarios(filename, num_scenarios=None, random_seed=42):
    """
    读取需求场景，可随机抽取指定数量的场景
    
    参数:
    filename: 场景文件路径
    num_scenarios: 需要抽取的场景数量，如果为None则读取所有场景
    random_seed: 随机种子，确保结果可重现
    """
    all_scenarios = pd.read_csv(filename)
    
    if num_scenarios is None or num_scenarios >= len(all_scenarios):
        return all_scenarios
    
    # 设置随机种子确保结果可重现
    if random_seed is not None:
        random.seed(random_seed)
    
    # 随机抽取指定数量的场景
    selected_indices = random.sample(range(len(all_scenarios)), num_scenarios)
    selected_scenarios = all_scenarios.iloc[selected_indices].reset_index(drop=True)
    
    print(f"从 {len(all_scenarios)} 个总场景中随机抽取了 {num_scenarios} 个场景")
    return selected_scenarios


# 读取额外信息
def read_additional_info(filename):
    with open(filename, 'r') as f:
        data = json.load(f)
    return data['foods'], data['substitutions'], data['storage_capacity']

def build_optimization_model(foods, substitutions, storage_capacity, demand_scenarios):
    """构建修正后的优化模型"""
    num_scenarios = len(demand_scenarios)
    model = gp.Model("CruiseShipFoodProvisioning_Corrected")
    
    # 第一阶段变量：采购决策
    x = model.addVars(foods.keys(), vtype=GRB.CONTINUOUS, name="x", lb=0)
    xk = model.addVars(foods.keys(), storage_capacity.keys(), vtype=GRB.CONTINUOUS, name="xk", lb=0)
    
    # 第二阶段变量：只定义有效的替代关系
    u = {}  # u[i,j,s]: 用食品j替代食品i的数量
    for i in foods:
        if i in substitutions:
            for sub in substitutions[i]:
                j = sub['food']
                for s in range(num_scenarios):
                    u_key = (i, j, s)
                    u[u_key] = model.addVar(vtype=GRB.CONTINUOUS, name=f"u_{i}_{j}_{s}", lb=0)
    
    w = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.CONTINUOUS, name="w", lb=0)
    
    # 辅助变量用于线性化max函数
    M = 1e7  # 大M常数
    a_vars = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.BINARY, name="a")
    beta_vars = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.BINARY, name="beta")
    S_b = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.CONTINUOUS, name="S_b", lb=0)
    R_b = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.CONTINUOUS, name="R_b", lb=0)
    
    # 目标函数：最小化总期望成本
    first_stage_cost = gp.quicksum(foods[i]['cost'] * xk[i, k] for i in foods for k in storage_capacity)
    second_stage_cost = 0
    
    for s in range(num_scenarios):
        scenario_cost = 0
        for i in foods:
            demand = demand_scenarios.iloc[s][i] if i in demand_scenarios.columns else demand_scenarios.iloc[s, list(foods.keys()).index(i)]
            
            # 线性化初始短缺和剩余计算
            model.addConstr(S_b[i, s] >= demand - x[i], f"shortage_lb_{i}_{s}")
            model.addConstr(S_b[i, s] <= demand - x[i] + M * (1 - a_vars[i, s]), f"shortage_ub1_{i}_{s}")
            model.addConstr(S_b[i, s] <= M * a_vars[i, s], f"shortage_ub2_{i}_{s}")
            
            model.addConstr(R_b[i, s] >= x[i] - demand, f"surplus_lb_{i}_{s}")
            model.addConstr(R_b[i, s] <= x[i] - demand + M * (1 - beta_vars[i, s]), f"surplus_ub1_{i}_{s}")
            model.addConstr(R_b[i, s] <= M * beta_vars[i, s], f"surplus_ub2_{i}_{s}")
            
            model.addConstr(a_vars[i, s] + beta_vars[i, s] == 1, f"complementary_{i}_{s}")
            
            # 计算从食品i出发的替代总量
            substitution_from_i = gp.quicksum(
                u[i, j, s] for j in foods 
                if (i, j, s) in u
            )
            
            # 净缺货量（初始缺货 - 被替代的量）
            net_shortage = S_b[i, s] - substitution_from_i
            model.addConstr(net_shortage >= 0, f"net_shortage_nonneg_{i}_{s}")
            
            # 缺货惩罚成本（基于净缺货）
            scenario_cost += foods[i]['shortage_penalty'] * net_shortage
            
            # 替代惩罚成本
            if i in substitutions:
                for sub in substitutions[i]:
                    j = sub['food']
                    if (i, j, s) in u:
                        scenario_cost += sub['penalty'] * u[i, j, s]
            
            # 剩余价值（负成本）
            scenario_cost -= foods[i]['salvage_value'] * w[i, s]
        
        second_stage_cost += scenario_cost
    
    # 总目标函数
    total_cost = first_stage_cost + second_stage_cost / num_scenarios
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # 约束条件
    
    # 1. 存储容量约束
    for k in storage_capacity:
        model.addConstr(
            gp.quicksum(foods[i]['volume'] * xk[i, k] for i in foods) <= storage_capacity[k],
            f"storage_capacity_{k}"
        )
    
    # 2. 采购量平衡约束
    for i in foods:
        model.addConstr(
            x[i] == gp.quicksum(xk[i, k] for k in storage_capacity),
            f"purchase_balance_{i}"
        )
    
    # 3. 第二阶段约束
    for s in range(num_scenarios):
        for i in foods:
            # 约束3.1: 替代量不超过初始缺货量
            substitution_from_i = gp.quicksum(
                u[i, j, s] for j in foods 
                if (i, j, s) in u
            )
            model.addConstr(
                substitution_from_i <= S_b[i, s],
                f"substitution_limit_{i}_{s}"
            )
            
            # 约束3.2: 作为替代品被消耗的量不超过初始剩余量
            substitution_to_i = gp.quicksum(
                sub['calories_ratio'] * u[j, i, s] 
                for j in foods 
                if j in substitutions
                for sub in substitutions[j] 
                if sub['food'] == i and (j, i, s) in u
            )
            model.addConstr(
                substitution_to_i <= R_b[i, s],
                f"surplus_usage_limit_{i}_{s}"
            )
            # 约束3.2: 服务水平约束 - 替代量不超过需求量的5%
            demand = demand_scenarios.iloc[s][i] if i in demand_scenarios.columns else demand_scenarios.iloc[s, list(foods.keys()).index(i)]
            model.addConstr(
                substitution_from_i <= foods[i]['service_level'] * demand,
                f"service_level_limit_{i}_{s}"
            )
            # 约束3.3: 最终剩余量平衡
            model.addConstr(
                w[i, s] == R_b[i, s] - substitution_to_i + substitution_from_i,
                f"inventory_balance_{i}_{s}"
            )
    
    return model, x, xk, u, w, S_b, R_b

def analyze_solution(model, foods, substitutions, demand_scenarios, x, xk, u, w, S_b, R_b):
    """分析优化结果"""
    if model.status != gp.GRB.OPTIMAL:
        print("未找到最优解")
        return None, 0, 0, 0
    
    num_scenarios = len(demand_scenarios)
    
    print("\n" + "=" * 80)
    print("优化结果分析")
    print("=" * 80)
    
    # 统计缺货和替代情况
    product_stats = {}
    total_initial_shortage = 0
    total_final_shortage = 0
    total_substitution = 0
    
    for i in foods:
        initial_shortage = sum(S_b[i, s].X for s in range(num_scenarios))
        substitution_out = sum(u[i, j, s].X for j in foods for s in range(num_scenarios) if (i, j, s) in u)
        final_shortage = max(0, initial_shortage - substitution_out)
        
        total_initial_shortage += initial_shortage
        total_final_shortage += final_shortage
        total_substitution += substitution_out
        
        product_stats[i] = {
            'purchase': x[i].X,
            'initial_shortage': initial_shortage,
            'substitution_out': substitution_out,
            'final_shortage': final_shortage,
            'reduction': initial_shortage - final_shortage
        }
    
    # 打印产品统计
    print(f"{'产品':<15} {'采购量':>10} {'初始缺货':>10} {'替代量':>10} {'最终缺货':>10} {'减少量':>10}")
    print("-" * 75)
    for product, stats in product_stats.items():
        print(f"{product:<15} {stats['purchase']:>10.2f} {stats['initial_shortage']:>10.2f} "
              f"{stats['substitution_out']:>10.2f} {stats['final_shortage']:>10.2f} {stats['reduction']:>10.2f}")
    
    print("-" * 75)
    print(f"{'总计':<15} {'':>10} {total_initial_shortage:>10.2f} {total_substitution:>10.2f} "
          f"{total_final_shortage:>10.2f} {total_initial_shortage-total_final_shortage:>10.2f}")
    
    return product_stats, total_initial_shortage, total_final_shortage, total_substitution

def analyze_solution(model, foods, substitutions, demand_scenarios, x, xk, u, w, S_b, R_b):
    """分析优化结果"""
    if model.status != gp.GRB.OPTIMAL:
        print("未找到最优解")
        return None, 0, 0, 0
    
    num_scenarios = len(demand_scenarios)
    
    print("\n" + "=" * 80)
    print("优化结果分析")
    print("=" * 80)
    
    # 统计缺货和替代情况
    product_stats = {}
    total_initial_shortage = 0
    total_final_shortage = 0
    total_substitution = 0
    
    for i in foods:
        initial_shortage = sum(S_b[i, s].X for s in range(num_scenarios))
        substitution_out = sum(u[i, j, s].X for j in foods for s in range(num_scenarios) if (i, j, s) in u)
        final_shortage = max(0, initial_shortage - substitution_out)
        
        total_initial_shortage += initial_shortage
        total_final_shortage += final_shortage
        total_substitution += substitution_out
        
        product_stats[i] = {
            'purchase': x[i].X,
            'initial_shortage': initial_shortage,
            'substitution_out': substitution_out,
            'final_shortage': final_shortage,
            'reduction': initial_shortage - final_shortage
        }
    
    # 打印产品统计
    print(f"{'产品':<15} {'采购量':>10} {'初始缺货':>10} {'替代量':>10} {'最终缺货':>10} {'减少量':>10}")
    print("-" * 75)
    for product, stats in product_stats.items():
        print(f"{product:<15} {stats['purchase']:>10.2f} {stats['initial_shortage']:>10.2f} "
              f"{stats['substitution_out']:>10.2f} {stats['final_shortage']:>10.2f} {stats['reduction']:>10.2f}")
    
    print("-" * 75)
    print(f"{'总计':<15} {'':>10} {total_initial_shortage:>10.2f} {total_substitution:>10.2f} "
          f"{total_final_shortage:>10.2f} {total_initial_shortage-total_final_shortage:>10.2f}")
    
    return product_stats, total_initial_shortage, total_final_shortage, total_substitution

def cost_comparison_analysis(model, foods, substitutions, demand_scenarios, product_stats, total_final_shortage):
    """成本对比分析"""
    print("\n" + "=" * 80)
    print("成本对比分析")
    print("=" * 80)
    
    # 固定采购策略成本
    fixed_cost = calculate_fixed_purchase_cost(foods, demand_scenarios)
    total_fixed_shortage = calculate_total_shortage(foods, demand_scenarios)
    
    if model.status == gp.GRB.OPTIMAL:
        # 优化策略成本分解
        optimized_total_cost = model.objVal
        
        # 第一阶段成本
        optimized_first_stage_cost = 0
        for i in foods:
            for k in storage_capacity:
                optimized_first_stage_cost += foods[i]['cost'] * xk[i, k].X
        
        # 第二阶段成本
        shortage_penalty_cost = 0
        substitution_penalty_cost = 0
        salvage_value_total = 0
        num_scenarios = len(demand_scenarios)
        
        for s in range(num_scenarios):
            for i in foods:
                # 净缺货惩罚
                substitution_from_i = sum(u[i, j, s].X for j in foods if (i, j, s) in u)
                net_shortage = max(0, S_b[i, s].X - substitution_from_i)
                shortage_penalty_cost += foods[i]['shortage_penalty'] * net_shortage
                
                # 替代惩罚
                if i in substitutions:
                    for sub in substitutions[i]:
                        j = sub['food']
                        if (i, j, s) in u:
                            substitution_penalty_cost += sub['penalty'] * u[i, j, s].X
                
                # 剩余价值
                salvage_value_total += foods[i]['salvage_value'] * w[i, s].X
        
        avg_second_stage_cost = (shortage_penalty_cost + substitution_penalty_cost - salvage_value_total) / num_scenarios
        
        print("优化策略成本分解:")
        print("-" * 50)
        print(f"第一阶段采购成本: {optimized_first_stage_cost:.2f}")
        print(f"第二阶段期望成本: {avg_second_stage_cost:.2f}")
        print(f"  其中：")
        print(f"  - 缺货惩罚成本: {shortage_penalty_cost/num_scenarios:.2f}")
        print(f"  - 替代惩罚成本: {substitution_penalty_cost/num_scenarios:.2f}")
        print(f"  - 剩余价值: {salvage_value_total/num_scenarios:.2f}")
        print(f"总期望成本: {optimized_total_cost:.2f}")
        
        print("\n固定采购策略成本:")
        print("-" * 50)
        fixed_first_stage = sum(foods[i]['cost'] * weekly_demand_mean[i] for i in foods)
        fixed_second_stage = fixed_cost - fixed_first_stage
        print(f"第一阶段采购成本: {fixed_first_stage:.2f}")
        print(f"第二阶段期望成本: {fixed_second_stage:.2f}")
        print(f"总期望成本: {fixed_cost:.2f}")
        
        # 对比分析
        cost_saving = fixed_cost - optimized_total_cost
        shortage_reduction = total_fixed_shortage - total_final_shortage
        
        print("\n对比结果:")
        print("-" * 50)
        print(f"成本节省: {cost_saving:.2f} ({cost_saving/fixed_cost*100:.1f}%)")
        print(f"缺货减少: {shortage_reduction:.2f} kg ({shortage_reduction/total_fixed_shortage*100:.1f}%)")
        
        if cost_saving > 0 and shortage_reduction > 0:
            print("✅ 优化策略在成本和缺货量两方面都表现更好")
        elif cost_saving > 0:
            print("⚠️  优化策略成本更低")
        elif shortage_reduction > 0:
            print("⚠️  优化策略缺货量更少")
        else:
            print("❌ 优化策略未改善性能")


def analyze_solution_with_comparison(model, foods, substitutions, demand_scenarios, x, xk, u, w, S_b, R_b):
    """分析优化结果并与固定策略比较"""
    if model.status != gp.GRB.OPTIMAL:
        print("未找到最优解")
        return None, 0, 0, 0, None
    
    num_scenarios = len(demand_scenarios)
    
    print("\n" + "=" * 80)
    print("优化结果分析与固定策略比较")
    print("=" * 80)
    
    # 统计缺货和替代情况
    product_stats = {}
    total_initial_shortage = 0
    total_final_shortage = 0
    total_substitution = 0
    
    # 计算固定策略的采购量（按平均需求采购）
    fixed_purchase = {i: weekly_demand_mean[i] for i in foods}
    
    for i in foods:
        initial_shortage = sum(S_b[i, s].X for s in range(num_scenarios))
        substitution_out = sum(u[i, j, s].X for j in foods for s in range(num_scenarios) if (i, j, s) in u)
        final_shortage = max(0, initial_shortage - substitution_out)
        
        total_initial_shortage += initial_shortage
        total_final_shortage += final_shortage
        total_substitution += substitution_out
        
        # 计算固定策略下的缺货量
        fixed_shortage = 0
        for s in range(num_scenarios):
            demand = demand_scenarios.iloc[s][i] if i in demand_scenarios.columns else demand_scenarios.iloc[s, list(foods.keys()).index(i)]
            fixed_shortage += max(0, demand - fixed_purchase[i])
        
        product_stats[i] = {
            'purchase': x[i].X,
            'fixed_purchase': fixed_purchase[i],
            'initial_shortage': initial_shortage,
            'substitution_out': substitution_out,
            'final_shortage': final_shortage,
            'reduction': initial_shortage - final_shortage,
            'fixed_shortage': fixed_shortage,
            'shortage_improvement': fixed_shortage - final_shortage
        }
    
    # 打印产品统计对比
    print(f"{'产品':<15} {'优化采购':>10} {'固定采购':>10} {'优化缺货':>10} {'固定缺货':>10} {'改进':>10} {'替代量':>10}")
    print("-" * 95)
    for product, stats in product_stats.items():
        improvement_rate = (stats['shortage_improvement'] / stats['fixed_shortage'] * 100) if stats['fixed_shortage'] > 0 else 0
        print(f"{product:<15} {stats['purchase']:>10.2f} {stats['fixed_purchase']:>10.2f} "
              f"{stats['final_shortage']:>10.2f} {stats['fixed_shortage']:>10.2f} "
              f"{stats['shortage_improvement']:>10.2f} {stats['substitution_out']:>10.2f}")
    
    print("-" * 95)
    
    # 计算固定策略总缺货
    total_fixed_shortage = sum(stats['fixed_shortage'] for stats in product_stats.values())
    total_improvement = total_fixed_shortage - total_final_shortage
    improvement_rate = (total_improvement / total_fixed_shortage * 100) if total_fixed_shortage > 0 else 0
    
    print(f"{'总计':<15} {'':>10} {'':>10} {total_final_shortage:>10.2f} {total_fixed_shortage:>10.2f} "
          f"{total_improvement:>10.2f} {total_substitution:>10.2f}")
    
    print(f"\n缺货改进总结:")
    print(f"- 固定策略总缺货: {total_fixed_shortage:.2f} kg")
    print(f"- 优化策略总缺货: {total_final_shortage:.2f} kg")
    print(f"- 缺货减少量: {total_improvement:.2f} kg ({improvement_rate:.1f}%)")
    print(f"- 总替代量: {total_substitution:.2f} kg")
    
    return product_stats, total_initial_shortage, total_final_shortage, total_substitution, total_fixed_shortage

def detailed_cost_comparison(model, foods, substitutions, demand_scenarios, x, xk, u, w, S_b, R_b):
    """详细的成本对比分析"""
    if model.status != gp.GRB.OPTIMAL:
        return None, None
    
    num_scenarios = len(demand_scenarios)
    
    # 优化策略成本计算
    optimized_purchase_cost = sum(foods[i]['cost'] * xk[i, k].X for i in foods for k in storage_capacity)
    
    shortage_penalty_cost = 0
    substitution_penalty_cost = 0
    salvage_value_total = 0
    
    for s in range(num_scenarios):
        for i in foods:
            # 净缺货惩罚成本
            substitution_from_i = sum(u[i, j, s].X for j in foods if (i, j, s) in u)
            net_shortage = max(0, S_b[i, s].X - substitution_from_i)
            shortage_penalty_cost += foods[i]['shortage_penalty'] * net_shortage
            
            # 替代惩罚成本
            if i in substitutions:
                for sub in substitutions[i]:
                    j = sub['food']
                    if (i, j, s) in u:
                        substitution_penalty_cost += sub['penalty'] * u[i, j, s].X
            
            # 剩余价值
            salvage_value_total += foods[i]['salvage_value'] * w[i, s].X
    
    # 计算期望成本
    avg_shortage_cost = shortage_penalty_cost / num_scenarios
    avg_substitution_cost = substitution_penalty_cost / num_scenarios
    avg_salvage_value = salvage_value_total / num_scenarios
    
    optimized_total_cost = optimized_purchase_cost + avg_shortage_cost + avg_substitution_cost - avg_salvage_value
    
    # 固定策略成本计算
    fixed_purchase_cost = sum(foods[i]['cost'] * weekly_demand_mean[i] for i in foods)
    
    fixed_shortage_cost = 0
    for s in range(num_scenarios):
        for i in foods:
            demand = demand_scenarios.iloc[s][i] if i in demand_scenarios.columns else demand_scenarios.iloc[s, list(foods.keys()).index(i)]
            shortage = max(0, demand - weekly_demand_mean[i])
            fixed_shortage_cost += foods[i]['shortage_penalty'] * shortage
    
    avg_fixed_shortage_cost = fixed_shortage_cost / num_scenarios
    fixed_total_cost = fixed_purchase_cost + avg_fixed_shortage_cost
    
    # 打印成本对比
    print(f"\n成本对比分析:")
    print("-" * 60)
    print(f"{'成本项目':<20} {'优化策略':<15} {'固定策略':<15} {'差异':<15}")
    print("-" * 60)
    print(f"{'采购成本':<20} {optimized_purchase_cost:<15.2f} {fixed_purchase_cost:<15.2f} {optimized_purchase_cost - fixed_purchase_cost:<15.2f}")
    print(f"{'缺货惩罚成本':<20} {avg_shortage_cost:<15.2f} {avg_fixed_shortage_cost:<15.2f} {avg_shortage_cost - avg_fixed_shortage_cost:<15.2f}")
    print(f"{'替代惩罚成本':<20} {avg_substitution_cost:<15.2f} {'0.00':<15} {avg_substitution_cost:<15.2f}")
    print(f"{'剩余价值':<20} {-avg_salvage_value:<15.2f} {'0.00':<15} {-avg_salvage_value:<15.2f}")
    print("-" * 60)
    print(f"{'总成本':<20} {optimized_total_cost:<15.2f} {fixed_total_cost:<15.2f} {optimized_total_cost - fixed_total_cost:<15.2f}")
    
    cost_saving = fixed_total_cost - optimized_total_cost
    saving_rate = (cost_saving / fixed_total_cost * 100) if fixed_total_cost > 0 else 0
    
    print(f"\n成本节省分析:")
    print(f"- 成本节省金额: {cost_saving:.2f}")
    print(f"- 成本节省比例: {saving_rate:.2f}%")
    
    if cost_saving > 0:
        print("✅ 优化策略在成本上表现更好")
    else:
        print("⚠️  固定策略成本更低")
    
    return {
        'optimized': {
            'purchase_cost': optimized_purchase_cost,
            'shortage_cost': avg_shortage_cost,
            'substitution_cost': avg_substitution_cost,
            'salvage_value': avg_salvage_value,
            'total_cost': optimized_total_cost
        },
        'fixed': {
            'purchase_cost': fixed_purchase_cost,
            'shortage_cost': avg_fixed_shortage_cost,
            'total_cost': fixed_total_cost
        },
        'saving': cost_saving,
        'saving_rate': saving_rate
    }






# 主执行流程
if __name__ == "__main__":
    # 参数设置
    NUM_REPETITIONS = 10  # 重复计算次数
    NUM_SCENARIOS = 80    # 每次抽取的场景数
    RANDOM_SEED_BASE = 42 # 随机种子基准
    
    # 存储每次运行的结果
    all_results = []
    fixed_strategy_results = []
    
    print(f"开始进行 {NUM_REPETITIONS} 次重复计算，每次使用 {NUM_SCENARIOS} 个场景")
    print(f"{'='*80}")
    
    for repetition in range(NUM_REPETITIONS):
        print(f"\n{'='*60}")
        print(f"第 {repetition + 1}/{NUM_REPETITIONS} 次运行")
        print(f"{'='*60}")
        
        # 每次使用不同的随机种子
        current_seed = RANDOM_SEED_BASE + repetition
        
        # 读取数据（随机抽取指定数量的场景）
        demand_scenarios = read_demand_scenarios(
            'd1demand_scenarios.csv', 
            num_scenarios=NUM_SCENARIOS,
            random_seed=current_seed
        )
        
        foods, substitutions, storage_capacity = read_additional_info('d1additional_info.json')
        
        print(f"数据加载完成:")
        print(f"- 食品种类: {len(foods)}")
        print(f"- 需求场景数: {len(demand_scenarios)}")
        print(f"- 存储类型: {list(storage_capacity.keys())}")
        
        # 计算固定策略结果（使用相同的场景）
        fixed_cost = calculate_fixed_purchase_cost(foods, demand_scenarios)
        total_fixed_shortage = calculate_total_shortage(foods, demand_scenarios)
        
        fixed_strategy_results.append({
            'repetition': repetition + 1,
            'seed': current_seed,
            'total_cost': fixed_cost,
            'total_shortage': total_fixed_shortage
        })
        
        # 构建并求解优化模型
        model, x, xk, u, w, S_b, R_b = build_optimization_model(
            foods, substitutions, storage_capacity, demand_scenarios
        )
        
        # 设置求解参数
        model.setParam('OutputFlag', 1)
        model.setParam('TimeLimit', 600)  # 10分钟时间限制
        
        print("开始求解优化模型...")
        model.optimize()
        
        # 收集优化策略结果
        result = {
            'repetition': repetition + 1,
            'seed': current_seed,
            'status': model.status,
            'objective': model.objVal if model.status == gp.GRB.OPTIMAL else None,
            'num_scenarios': len(demand_scenarios),
            'fixed_cost': fixed_cost,
            'fixed_shortage': total_fixed_shortage
        }
        
        # 在主函数中替换原来的分析部分
        if model.status == gp.GRB.OPTIMAL:
            # 使用新的分析函数
            product_stats, total_initial_shortage, total_final_shortage, total_substitution, total_fixed_shortage = analyze_solution_with_comparison(
                model, foods, substitutions, demand_scenarios, x, xk, u, w, S_b, R_b
            )
            
            # 进行详细的成本对比
            cost_comparison = detailed_cost_comparison(
                model, foods, substitutions, demand_scenarios, x, xk, u, w, S_b, R_b
            )
            
            # 存储结果
            result.update({
                'total_initial_shortage': total_initial_shortage,
                'total_final_shortage': total_final_shortage,
                'total_substitution': total_substitution,
                'total_fixed_shortage': total_fixed_shortage,
                'product_stats': product_stats,
                'cost_comparison': cost_comparison
            })
            # 释放模型内存
            del model
    
    # 计算统计结果
    print(f"\n{'='*80}")
    print("总体统计结果 - 优化策略 vs 固定策略")
    print(f"{'='*80}")
    
    successful_runs = [r for r in all_results if r['status'] == gp.GRB.OPTIMAL]
    
    if successful_runs:
        # 优化策略统计
        avg_optimized_cost = sum(r['objective'] for r in successful_runs) / len(successful_runs)
        avg_optimized_shortage = sum(r['total_final_shortage'] for r in successful_runs) / len(successful_runs)
        
        optimized_costs = [r['objective'] for r in successful_runs]
        std_optimized_cost = (sum((obj - avg_optimized_cost) ** 2 for obj in optimized_costs) / len(optimized_costs)) ** 0.5
        
        # 固定策略统计（使用相同场景）
        avg_fixed_cost = sum(r['fixed_cost'] for r in successful_runs) / len(successful_runs)
        avg_fixed_shortage = sum(r['fixed_shortage'] for r in successful_runs) / len(successful_runs)
        
        fixed_costs = [r['fixed_cost'] for r in successful_runs]
        std_fixed_cost = (sum((cost - avg_fixed_cost) ** 2 for cost in fixed_costs) / len(fixed_costs)) ** 0.5
        
        # 改进统计
        avg_cost_saving = sum(r['cost_saving'] for r in successful_runs) / len(successful_runs)
        avg_shortage_reduction = sum(r['shortage_reduction'] for r in successful_runs) / len(successful_runs)
        
        cost_savings = [r['cost_saving'] for r in successful_runs]
        std_cost_saving = (sum((saving - avg_cost_saving) ** 2 for saving in cost_savings) / len(cost_savings)) ** 0.5
        
        print(f"成功运行次数: {len(successful_runs)}/{NUM_REPETITIONS}")
        print(f"\n成本对比:")
        print(f"{'策略':<15} {'平均成本':<15} {'标准差':<15} {'变异系数':<15}")
        print("-" * 60)
        print(f"{'优化策略':<15} {avg_optimized_cost:<15.2f} {std_optimized_cost:<15.2f} {(std_optimized_cost/avg_optimized_cost)*100:<15.2f}%")
        print(f"{'固定策略':<15} {avg_fixed_cost:<15.2f} {std_fixed_cost:<15.2f} {(std_fixed_cost/avg_fixed_cost)*100:<15.2f}%")
        print(f"{'成本节省':<15} {avg_cost_saving:<15.2f} {std_cost_saving:<15.2f} {(std_cost_saving/avg_cost_saving)*100 if avg_cost_saving > 0 else 0:<15.2f}%")
        
        print(f"\n缺货量对比:")
        print(f"{'策略':<15} {'平均缺货量(kg)':<15} {'改进量(kg)':<15} {'改进百分比':<15}")
        print("-" * 60)
        print(f"{'优化策略':<15} {avg_optimized_shortage:<15.2f} {'-':<15} {'-':<15}")
        print(f"{'固定策略':<15} {avg_fixed_shortage:<15.2f} {'-':<15} {'-':<15}")
        print(f"{'缺货减少':<15} {'-':<15} {avg_shortage_reduction:<15.2f} {(avg_shortage_reduction/avg_fixed_shortage)*100:<15.2f}%")
        
        print(f"\n总体改进效果:")
        print(f"- 平均成本降低: {avg_cost_saving:.2f} ({(avg_cost_saving/avg_fixed_cost)*100:.2f}%)")
        print(f"- 平均缺货减少: {avg_shortage_reduction:.2f} kg ({(avg_shortage_reduction/avg_fixed_shortage)*100:.2f}%)")
        
        # 性能评估
        positive_improvements = len([r for r in successful_runs if r['cost_saving'] > 0 and r['shortage_reduction'] > 0])
        print(f"- 双重改进比例: {positive_improvements}/{len(successful_runs)} ({(positive_improvements/len(successful_runs))*100:.1f}%)")
        
        # 显示每次运行的详细对比
        print(f"\n详细对比结果:")
        print(f"{'运行':<6} {'种子':<8} {'优化成本':<12} {'固定成本':<12} {'成本节省':<12} {'节省%':<8} {'状态':<10}")
        print("-" * 80)
        for result in all_results:
            status_str = "最优" if result['status'] == gp.GRB.OPTIMAL else "失败"
            opt_cost_str = f"{result['objective']:.2f}" if result['objective'] is not None else "N/A"
            fixed_cost_str = f"{result['fixed_cost']:.2f}" if result['fixed_cost'] is not None else "N/A"
            
            if result['status'] == gp.GRB.OPTIMAL and result['cost_saving'] is not None:
                saving_percent = (result['cost_saving'] / result['fixed_cost']) * 100
                saving_str = f"{result['cost_saving']:.2f}"
                percent_str = f"{saving_percent:.1f}%"
            else:
                saving_str = "N/A"
                percent_str = "N/A"
            
            print(f"{result['repetition']:<6} {result['seed']:<8} {opt_cost_str:<12} {fixed_cost_str:<12} {saving_str:<12} {percent_str:<8} {status_str:<10}")
    
    else:
        print("所有运行均未找到最优解")
        
        # 显示固定策略结果
        if fixed_strategy_results:
            avg_fixed_cost = sum(r['total_cost'] for r in fixed_strategy_results) / len(fixed_strategy_results)
            avg_fixed_shortage = sum(r['total_shortage'] for r in fixed_strategy_results) / len(fixed_strategy_results)
            print(f"\n固定策略参考结果 (基于 {NUM_REPETITIONS} 次运行):")
            print(f"- 平均总成本: {avg_fixed_cost:.2f}")
            print(f"- 平均总缺货量: {avg_fixed_shortage:.2f} kg")
