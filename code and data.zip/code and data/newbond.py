# -*- coding: utf-8 -*-

import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import json
import numpy as np
from scipy import stats
from gurobi import build_optimization_model
import time

# 读取需求场景
def read_demand_scenarios(filename):
    return pd.read_csv(filename)

# 读取额外信息
def read_additional_info(filename):
    with open(filename, 'r') as f:
        data = json.load(f)
    return data['foods'], data['substitutions'], data['storage_capacity']

def calculate_statistical_bounds(foods, substitutions, storage_capacity, demand_scenarios, M=20, S=10):
    """
    计算SAA方法的统计上下界、gap和标准差百分比
    """
    print(f"\n开始计算统计边界: M={M}, S={S}")
    print("=" * 60)
    
    # 存储M个独立SAA问题的结果
    L_values = []  # 下界样本值
    solve_times = []  # 新增：存储求解时间
    best_solution = None
    best_objective = float('inf')
    
    # 1. 求解M个独立的SAA问题（下界估计）
    print("求解独立SAA问题计算下界...")
    for m in range(M):
        print(f"  求解第 {m+1}/{M} 个SAA问题...")
        
        # 从总场景中随机抽取S个场景
        scenario_indices = np.random.choice(len(demand_scenarios), S, replace=False)
        sampled_scenarios = demand_scenarios.iloc[scenario_indices]
        
        # 构建并求解SAA模型
        start_time = time.time()  # 开始计时
        
        model, x, xk, u, w, S_b, R_b = build_optimization_model(
            foods, substitutions, storage_capacity, sampled_scenarios
        )
        
        model.setParam('OutputFlag', 0)  # 关闭输出
        model.setParam('TimeLimit', 300)  # 5分钟时间限制
        
        model.optimize()
        
        end_time = time.time()  # 结束计时
        solve_time = end_time - start_time
        solve_times.append(solve_time)  # 记录求解时间
        
        if model.status == gp.GRB.OPTIMAL:
            objective_value = model.objVal
            L_values.append(objective_value)
            
            # 记录最佳解
            if objective_value < best_objective:
                best_objective = objective_value
                best_solution = {
                    'x_values': {i: x[i].X for i in foods},
                    'xk_values': {(i, k): xk[i, k].X for i in foods for k in storage_capacity},
                    'model': model
                }
            
            print(f"    第 {m+1} 个问题目标值: {objective_value:.2f}, 求解时间: {solve_time:.2f}秒")
        else:
            print(f"    第 {m+1} 个问题求解失败, 求解时间: {solve_time:.2f}秒")
    
    if not L_values:
        print("所有SAA问题都求解失败，无法计算边界")
        return None
    
    # 计算平均求解时间
    avg_solve_time = np.mean(solve_times)
    print(f"\nSAA问题求解时间统计:")
    print(f"  平均求解时间: {avg_solve_time:.2f} 秒")
    print(f"  最短求解时间: {np.min(solve_times):.2f} 秒")
    print(f"  最长求解时间: {np.max(solve_times):.2f} 秒")
    print(f"  总求解时间: {np.sum(solve_times):.2f} 秒")
    
    # 2. 计算下界统计量
    L_bar = np.mean(L_values)  # 样本均值
    s_L = np.std(L_values, ddof=1)  # 样本标准差
    t_value = stats.t.ppf(0.95, M-1)  # t分布分位数 (95%置信水平)
    
    LB = L_bar - t_value * s_L / np.sqrt(M)  # 下界
    
    # 计算下界标准差百分比
    std_lower_percent = (s_L / LB * 100) if LB != 0 else 0
    
    print(f"\n下界计算结果:")
    print(f"  样本均值 (L̄): {L_bar:.2f}")
    print(f"  样本标准差 (s_L): {s_L:.2f}")
    print(f"  t值 (t_{M-1,0.95}): {t_value:.4f}")
    print(f"  下界 (LB): {LB:.2f}")
    print(f"  下界标准差百分比: {std_lower_percent:.2f}%")
    
    # 3. 计算上界（使用大样本评估最佳解）
    print(f"\n使用大样本评估上界...")
    S_large = 20 * S  # 大样本数量
    
    if best_solution is None:
        print("没有可行解，无法计算上界")
        return None
    
    # 评估最佳解在大样本上的表现
    large_scenario_indices = np.random.choice(len(demand_scenarios), S_large, replace=False)
    large_scenarios = demand_scenarios.iloc[large_scenario_indices]
    
    # 构建评估模型（固定第一阶段决策）
    start_time_ub = time.time()  # 上界评估开始计时
    
    ub_model, ub_x, ub_xk, ub_u, ub_w, ub_S_b, ub_R_b = build_evaluation_model(
        foods, substitutions, storage_capacity, large_scenarios, best_solution
    )
    
    ub_model.setParam('OutputFlag', 0)
    ub_model.optimize()
    
    end_time_ub = time.time()  # 上界评估结束计时
    ub_solve_time = end_time_ub - start_time_ub
    
    print(f"  上界评估求解时间: {ub_solve_time:.2f} 秒")
    
    if ub_model.status == gp.GRB.OPTIMAL:
        UB_hat = ub_model.objVal
        
        # 为了计算上界标准差，需要多次评估
        print(f"计算上界标准差...")
        UB_samples = []
        ub_eval_times = []  # 新增：存储上界评估时间
        num_ub_evaluations = min(10, M)  # 评估次数
        
        for eval_idx in range(num_ub_evaluations):
            # 重新抽样评估
            eval_indices = np.random.choice(len(demand_scenarios), S_large, replace=False)
            eval_scenarios = demand_scenarios.iloc[eval_indices]
            
            eval_start_time = time.time()  # 单次评估开始计时
            
            eval_model, _, _, _, _, _, _ = build_evaluation_model(
                foods, substitutions, storage_capacity, eval_scenarios, best_solution
            )
            eval_model.setParam('OutputFlag', 0)
            eval_model.optimize()
            
            eval_end_time = time.time()  # 单次评估结束计时
            eval_time = eval_end_time - eval_start_time
            ub_eval_times.append(eval_time)
            
            if eval_model.status == gp.GRB.OPTIMAL:
                UB_samples.append(eval_model.objVal)
                print(f"  上界评估 {eval_idx+1}/{num_ub_evaluations}: {eval_model.objVal:.2f}, 时间: {eval_time:.2f}秒")
        
        # 计算上界统计量
        if UB_samples:
            UB_std = np.std(UB_samples, ddof=1)
            std_upper_percent = (UB_std / UB_hat * 100) if UB_hat != 0 else 0
            avg_ub_eval_time = np.mean(ub_eval_times)
        else:
            UB_std = 0
            std_upper_percent = 0
            avg_ub_eval_time = 0
        
        print(f"\n上界计算结果:")
        print(f"  大样本数量: {S_large}")
        print(f"  估计上界 (UB̂): {UB_hat:.2f}")
        print(f"  上界标准差: {UB_std:.2f}")
        print(f"  上界标准差百分比: {std_upper_percent:.2f}%")
        print(f"  上界评估平均时间: {avg_ub_eval_time:.2f} 秒")
        
        # 4. 计算最优性gap
        gap = max(0, UB_hat - LB)
        gap_percentage = (gap / UB_hat) * 100 if UB_hat > 0 else 0
        
        print(f"\n最优性gap分析:")
        print(f"  下界 (LB): {LB:.2f}")
        print(f"  上界 (UB̂): {UB_hat:.2f}")
        print(f"  绝对gap: {gap:.2f}")
        print(f"  相对gap: {gap_percentage:.2f}%")
        
        # 返回结果
        results = {
            'M': M,
            'S': S,
            'S_large': S_large,
            'L_values': L_values,
            'L_bar': L_bar,
            's_L': s_L,
            'LB': LB,
            'UB_hat': UB_hat,
            'UB_samples': UB_samples,
            'UB_std': UB_std,
            'gap': gap,
            'gap_percentage': gap_percentage,
            'std_lower_percent': std_lower_percent,
            'std_upper_percent': std_upper_percent,
            'best_solution': best_solution,
            'avg_solve_time': avg_solve_time,  # 新增：平均求解时间
        }
        
        return results
    else:
        print("上界评估失败")
        return None

def build_evaluation_model(foods, substitutions, storage_capacity, demand_scenarios, fixed_solution):
    """
    构建固定第一阶段决策的评估模型（用于上界计算）
    """
    num_scenarios = len(demand_scenarios)
    model = gp.Model("Evaluation_Model")
    
    # 固定第一阶段变量为常数
    x_fixed = fixed_solution['x_values']
    xk_fixed = fixed_solution['xk_values']
    
    # 第二阶段变量（与之前相同）
    u = {}
    for i in foods:
        if i in substitutions:
            for sub in substitutions[i]:
                j = sub['food']
                for s in range(num_scenarios):
                    u_key = (i, j, s)
                    u[u_key] = model.addVar(vtype=GRB.CONTINUOUS, name=f"u_{i}_{j}_{s}", lb=0)
    
    w = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.CONTINUOUS, name="w", lb=0)
    
    # 辅助变量
    M = 1e6
    a_vars = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.BINARY, name="a")
    beta_vars = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.BINARY, name="beta")
    S_b = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.CONTINUOUS, name="S_b", lb=0)
    R_b = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.CONTINUOUS, name="R_b", lb=0)
    
    # 目标函数：只有第二阶段成本（第一阶段成本为常数）
    first_stage_cost = sum(foods[i]['cost'] * xk_fixed[i, k] for i in foods for k in storage_capacity)
    second_stage_cost = 0
    
    for s in range(num_scenarios):
        scenario_cost = 0
        for i in foods:
            demand = demand_scenarios.iloc[s][i] if i in demand_scenarios.columns else demand_scenarios.iloc[s, list(foods.keys()).index(i)]
            x_i = x_fixed[i]
            
            # 线性化约束
            model.addConstr(S_b[i, s] >= demand - x_i, f"shortage_lb_{i}_{s}")
            model.addConstr(S_b[i, s] <= demand - x_i + M * (1 - a_vars[i, s]), f"shortage_ub1_{i}_{s}")
            model.addConstr(S_b[i, s] <= M * a_vars[i, s], f"shortage_ub2_{i}_{s}")
            
            model.addConstr(R_b[i, s] >= x_i - demand, f"surplus_lb_{i}_{s}")
            model.addConstr(R_b[i, s] <= x_i - demand + M * (1 - beta_vars[i, s]), f"surplus_ub1_{i}_{s}")
            model.addConstr(R_b[i, s] <= M * beta_vars[i, s], f"surplus_ub2_{i}_{s}")
            
            model.addConstr(a_vars[i, s] + beta_vars[i, s] == 1, f"complementary_{i}_{s}")
            
            # 计算替代总量
            substitution_from_i = gp.quicksum(
                u[i, j, s] for j in foods if (i, j, s) in u
            )
            
            # 净缺货量
            net_shortage = S_b[i, s] - substitution_from_i
            model.addConstr(net_shortage >= 0, f"net_shortage_nonneg_{i}_{s}")
            
            # 第二阶段成本
            scenario_cost += foods[i]['shortage_penalty'] * net_shortage
            
            if i in substitutions:
                for sub in substitutions[i]:
                    j = sub['food']
                    if (i, j, s) in u:
                        scenario_cost += sub['penalty'] * u[i, j, s]
            
            scenario_cost -= foods[i]['salvage_value'] * w[i, s]
        
        second_stage_cost += scenario_cost
    
    # 总目标函数 = 第一阶段固定成本 + 平均第二阶段成本
    total_cost = first_stage_cost + second_stage_cost / num_scenarios
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # 第二阶段约束（添加服务水平约束）
    for s in range(num_scenarios):
        for i in foods:
            substitution_from_i = gp.quicksum(
                u[i, j, s] for j in foods if (i, j, s) in u
            )
            
            # 物理可行性约束：替代量不超过初始短缺量
            model.addConstr(
                substitution_from_i <= S_b[i, s],
                f"substitution_limit_{i}_{s}"
            )
            
            # 服务水平约束：替代量不超过需求量的λ_i比例
            demand = demand_scenarios.iloc[s][i] if i in demand_scenarios.columns else demand_scenarios.iloc[s, list(foods.keys()).index(i)]
            model.addConstr(
                substitution_from_i <= foods[i]['service_level'] * demand,
                f"service_level_limit_{i}_{s}"
            )
            
            substitution_to_i = gp.quicksum(
                sub['calories_ratio'] * u[j, i, s] 
                for j in foods 
                if j in substitutions
                for sub in substitutions[j] 
                if sub['food'] == i and (j, i, s) in u
            )
            model.addConstr(
                substitution_to_i <= R_b[i, s],
                f"surplus_usage_limit_{i}_{s}"
            )
            
            model.addConstr(
                w[i, s] == R_b[i, s] - substitution_to_i + substitution_from_i,
                f"inventory_balance_{i}_{s}"
            )
    
    return model, None, None, u, w, S_b, R_b

def print_statistical_results(results):
    """打印统计结果"""
    if results is None:
        return
    
    print("\n" + "=" * 80)
    print("统计边界分析结果")
    print("=" * 80)
    
    print(f"参数设置:")
    print(f"  独立SAA问题数量 (M): {results['M']}")
    print(f"  每个SAA问题场景数 (S): {results['S']}")
    print(f"  上界评估样本数: {results['S_large']}")
    
    print(f"\n下界统计:")
    print(f"  样本值: {[f'{v:.2f}' for v in results['L_values']]}")
    print(f"  样本均值 (L̄): {results['L_bar']:.2f}")
    print(f"  样本标准差 (s_L): {results['s_L']:.2f}")
    print(f"  下界估计 (LB): {results['LB']:.2f}")
    print(f"  下界标准差百分比: {results['std_lower_percent']:.2f}%")
    
    print(f"\n上界估计:")
    print(f"  上界 (UB̂): {results['UB_hat']:.2f}")
    if results['UB_samples']:
        print(f"  上界样本值: {[f'{v:.2f}' for v in results['UB_samples']]}")
    print(f"  上界标准差: {results['UB_std']:.2f}")
    print(f"  上界标准差百分比: {results['std_upper_percent']:.2f}%")
    
    print(f"\n最优性gap:")
    print(f"  绝对gap: {results['gap']:.2f}")
    print(f"  相对gap: {results['gap_percentage']:.2f}%")

def analyze_multiple_scenario_sizes(foods, substitutions, storage_capacity, demand_scenarios, scenario_sizes, M=20):
    """
    分析不同场景数下的决策结果
    
    参数:
    scenario_sizes: list, 不同的场景数S
    M: int, 独立SAA问题数量
    
    返回:
    DataFrame: 包含表1格式的分析结果
    """
    analysis_results = []
    
    for S in scenario_sizes:
        print(f"\n{'='*60}")
        print(f"分析场景数 S={S}")
        print(f"{'='*60}")
        
        results = calculate_statistical_bounds(foods, substitutions, storage_capacity, demand_scenarios, M=M, S=S)
        
        if results is not None:
            result_row = {
                '场景数': S,
                '目标值下界': results['LB'],
                '目标值上界': results['UB_hat'],
                'Gap (%)': results['gap_percentage'],
                '下界标准差(%)': results['std_lower_percent'],
                '上界标准差(%)': results['std_upper_percent'],
                'avg_solve_time': results['avg_solve_time']# 新增：平均求解时间
            }
            analysis_results.append(result_row)
    
    return pd.DataFrame(analysis_results)

# 在主函数中使用
if __name__ == "__main__":
    # 读取数据
    demand_scenarios = read_demand_scenarios('bddemand_scenarios.csv')
    foods, substitutions, storage_capacity = read_additional_info('bdadditional_info.json')
    
    # 分析不同场景数
    scenario_sizes = [10, 20, 30, 40, 60, 80, 100]
    # scenario_sizes = [80]
    df_results = analyze_multiple_scenario_sizes(foods, substitutions, storage_capacity, demand_scenarios, scenario_sizes, M=20)
    
    # 格式化输出
    pd.set_option('display.float_format', '{:.2f}'.format)
    print("\n" + "="*80)
    print("表1 不同场景数下的决策结果")
    print("="*80)
    print(df_results.to_string(index=False))
    
    # 保存到CSV
    df_results.to_csv('bdscenario_analysis_results.csv', index=False, encoding='utf-8-sig')
    print(f"\n结果已保存到 'scenario_analysis_results.csv'")

