# -*- coding: utf-8 -*-
"""
Created on Mon Nov  3 13:11:15 2025

@author: 孙潍霖
"""

# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
import json

# 食物种类及其参数 - 添加service_level参数
foods = {
    'eggs': {'volume': 0.0001, 'cost': 8.10, 'calories': 1310, 'shortage_penalty': 12.15, 'salvage_value': 0.5, 'service_level': 0.05},
    'chicken': {'volume': 0.001, 'cost': 20.67, 'calories': 1825, 'shortage_penalty': 2.0, 'salvage_value': 1.0, 'service_level': 0.05},
    'beef': {'volume': 0.001, 'cost': 61.13, 'calories': 1250, 'shortage_penalty': 3.0, 'salvage_value': 1.5, 'service_level': 0.05},
    'ice_cream': {'volume': 0.0005, 'cost': 20.0, 'calories': 2520, 'shortage_penalty': 1.5, 'salvage_value': 0.75, 'service_level': 0.05},
    'potatoes': {'volume': 0.0008, 'cost': 3.5, 'calories': 805, 'shortage_penalty': 0.75, 'salvage_value': 0.35, 'service_level': 0.05},
    'flour': {'volume': 0.0006, 'cost': 5.5, 'calories': 3600, 'shortage_penalty': 1.0, 'salvage_value': 0.5, 'service_level': 0.05},
    'salmon': {'volume': 0.0012, 'cost': 75.0, 'calories': 2080, 'shortage_penalty': 2.5, 'salvage_value': 1.25, 'service_level': 0.05},
    'lobster_tails': {'volume': 0.002, 'cost': 200.0, 'calories': 970, 'shortage_penalty': 3.5, 'salvage_value': 1.75, 'service_level': 0.05},
    'french_fries': {'volume': 0.0008, 'cost': 20.0, 'calories': 2000, 'shortage_penalty': 2.0, 'salvage_value': 1.0, 'service_level': 0.05},
    'bacon': {'volume': 0.001, 'cost': 55.0, 'calories': 2500, 'shortage_penalty': 2.5, 'salvage_value': 1.25, 'service_level': 0.05},
    'tortillas': {'volume': 0.0005, 'cost': 10.0, 'calories': 2370, 'shortage_penalty': 1.5, 'salvage_value': 0.75, 'service_level': 0.05},
    'chicken_wings': {'volume': 0.001, 'cost': 35.0, 'calories': 2100, 'shortage_penalty': 2.0, 'salvage_value': 1.0, 'service_level': 0.05},
    'coffee': {'volume': 0.0002, 'cost': 125.0, 'calories': 1, 'shortage_penalty': 1.0, 'salvage_value': 0.5, 'service_level': 0.05},
    'tea': {'volume': 0.0002, 'cost': 200.0, 'calories': 1, 'shortage_penalty': 1.0, 'salvage_value': 0.5, 'service_level': 0.05}
}

# 直接修改现有的 foods 字典
for food, attributes in foods.items():
    attributes['shortage_penalty'] = attributes['cost'] * 2
    attributes['salvage_value'] = -attributes['cost'] * 0.1
    attributes['cost'] = attributes['cost'] 
    # 设置服务水平参数，默认为5%
    attributes['service_level'] = 0.05

aaa = 0.1

# 食物之间的替代关系（所有penalty设置为pi的0.2倍）
substitutions = {
    'beef': [
        {'food': 'chicken', 'calories_ratio': foods['beef']['calories'] / foods['chicken']['calories'], 'penalty': foods['beef']['cost'] * aaa},
        {'food': 'salmon', 'calories_ratio': foods['beef']['calories'] / foods['salmon']['calories'], 'penalty': foods['beef']['cost'] * aaa}
    ],
    'chicken': [
        {'food': 'beef', 'calories_ratio': foods['chicken']['calories'] / foods['beef']['calories'], 'penalty': foods['chicken']['cost'] * aaa},
        {'food': 'salmon', 'calories_ratio': foods['chicken']['calories'] / foods['salmon']['calories'], 'penalty': foods['chicken']['cost'] * aaa}
    ],
    'salmon': [
        {'food': 'beef', 'calories_ratio': foods['salmon']['calories'] / foods['beef']['calories'], 'penalty': foods['salmon']['cost'] * aaa},
        {'food': 'chicken', 'calories_ratio': foods['salmon']['calories'] / foods['chicken']['calories'], 'penalty': foods['salmon']['cost'] * aaa}
    ],
    'potatoes': [
        {'food': 'french_fries', 'calories_ratio': foods['potatoes']['calories'] / foods['french_fries']['calories'], 'penalty': foods['potatoes']['cost'] * aaa}
    ],
    'french_fries': [
        {'food': 'potatoes', 'calories_ratio': foods['french_fries']['calories'] / foods['potatoes']['calories'], 'penalty': foods['french_fries']['cost'] * aaa}
    ],
    'bacon': [
        {'food': 'chicken_wings', 'calories_ratio': foods['bacon']['calories'] / foods['chicken_wings']['calories'], 'penalty': foods['bacon']['cost'] * aaa}
    ],
    'chicken_wings': [
        {'food': 'bacon', 'calories_ratio': foods['chicken_wings']['calories'] / foods['bacon']['calories'], 'penalty': foods['chicken_wings']['cost'] * aaa}
    ],
    'coffee': [
        {'food': 'tea', 'calories_ratio': 1.0, 'penalty': foods['coffee']['cost'] * aaa}
    ],
    'tea': [
        {'food': 'coffee', 'calories_ratio': 1.0, 'penalty': foods['tea']['cost'] * aaa}
    ]
}

# 存储容量（单位：立方米）
storage_capacity = {
    'frozen': 100,
    'refrigerated': 80,
    'ambient': 50
}

# 每周消耗量的均值（单位：公斤）
weekly_demand_mean = {
    'eggs': 60000 * 0.05,  # 鸡蛋，假设每个鸡蛋重50克
    'chicken': 9700 * 0.453592,  # 鸡肉，磅转公斤
    'beef': 15000 * 0.453592,  # 牛肉，磅转公斤
    'ice_cream': 700 * 0.453592,  # 冰淇淋，磅转公斤
    'potatoes': 20000 * 0.453592,  # 土豆，磅转公斤
    'flour': 12600 * 0.453592,  # 面粉，磅转公斤
    'salmon': 2500 * 0.453592,  # 三文鱼，磅转公斤
    'lobster_tails': 2100 * 0.453592,  # 龙虾尾，磅转公斤
    'french_fries': 5000 * 0.453592,  # 薯条，磅转公斤
    'bacon': 5300 * 0.453592,  # 培根，磅转公斤
    'tortillas': 12000 * 0.453592,  # 玉米饼，磅转公斤
    'chicken_wings': 2000 * 0.453592,  # 鸡翅，磅转公斤
    'coffee': 1500 * 0.453592,  # 咖啡，磅转公斤
    'tea': 1500 * 0.453592  # 茶，磅转公斤
}

def generate_demand_scenarios(num_scenarios):
    """
    生成需求场景 - 简化版本
    直接基于总需求均值和10%方差生成
    """
    scenarios = []
    
    for _ in range(num_scenarios):
        scenario = {}
        for food, mean_demand in weekly_demand_mean.items():
            # 计算标准差：均值的10%
            std_demand = mean_demand * 0.1
            
            # 生成正态分布的需求，确保非负
            demand = np.random.normal(mean_demand, std_demand)
            demand = max(0, demand)  # 确保需求非负
            
            scenario[food] = demand
        
        scenarios.append(scenario)
    
    return scenarios

# 保存需求场景到CSV文件
def save_demand_scenarios_to_csv(scenarios, filename):
    df = pd.DataFrame(scenarios)
    df.to_csv(filename, index=False)

# 保存额外信息到JSON文件
def save_additional_info_to_json(foods, substitutions, storage_capacity, filename):
    data = {
        'foods': foods,
        'substitutions': substitutions,
        'storage_capacity': storage_capacity
    }
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)

def check_and_filter_substitutions(foods, substitutions):
    """
    检验并过滤替代关系，删除不满足 P_j * q_ij + d_ij > p_i > d_ij 条件的替代关系
    其中：i是需求方（被替代的食物），j是供应方（替代的食物）
    q_ij = 需要多少单位的食物j来替代1单位的食物i
    """
    print("=" * 80)
    print("检验并过滤替代关系: P_j * q_ij + d_ij > p_i > d_ij")
    print("其中：i是需求方（被替代的食物），j是供应方（替代的食物）")
    print("q_ij = 需要多少单位的j来替代1单位的i")
    print("=" * 80)
    
    # 创建新的替代关系字典（过滤后的）
    filtered_substitutions = {}
    removed_count = 0
    total_count = 0
    
    for demand_food, sub_list in substitutions.items():
        filtered_list = []
        
        for sub in sub_list:
            total_count += 1
            supply_food = sub['food']
            # demand_food 是需求方 i（被替代的食物）
            # supply_food 是供应方 j（替代的食物）
            p_i = foods[demand_food]['shortage_penalty']  # 需求方的缺货惩罚
            p_j = foods[supply_food]['shortage_penalty']  # 供应方的缺货惩罚
            # q_ij = 需要多少单位的j来替代1单位的i
            q_ij = foods[demand_food]['calories'] / foods[supply_food]['calories']
            d_ij = sub['penalty']  # 替代成本（从j替代i）
            
            # 计算不等式两边
            left_side = p_j * q_ij + d_ij
            right_side = p_i
            
            # 检查两个条件
            condition1 = p_i > d_ij  # p_i > d_ij
            condition2 = left_side > right_side  # P_j * q_ij + d_ij > p_i
            
            if condition1 and condition2:
                # 满足条件，保留这个替代关系
                filtered_list.append(sub)
                print(f"✓ {demand_food:15} <- {supply_food:15}: 满足条件，保留")
                print(f"   p_i({demand_food}) = {p_i:6.2f}, p_j({supply_food}) = {p_j:6.2f}")
                print(f"   q_ij = {q_ij:6.3f} (需要{q_ij:.3f}kg的{supply_food}替代1kg的{demand_food})")
                print(f"   d_ij = {d_ij:6.2f}")
                print(f"   P_j*q_ij + d_ij = {p_j:.2f} * {q_ij:.3f} + {d_ij:.2f} = {left_side:6.2f}")
            else:
                # 不满足条件，删除这个替代关系
                removed_count += 1
                print(f"✗ {demand_food:15} <- {supply_food:15}: 不满足条件，删除")
                print(f"   p_i({demand_food}) = {p_i:6.2f}, p_j({supply_food}) = {p_j:6.2f}")
                print(f"   q_ij = {q_ij:6.3f} (需要{q_ij:.3f}kg的{supply_food}替代1kg的{demand_food})")
                print(f"   d_ij = {d_ij:6.2f}")
                print(f"   P_j*q_ij + d_ij = {p_j:.2f} * {q_ij:.3f} + {d_ij:.2f} = {left_side:6.2f}")
                if not condition1:
                    print(f"   失败原因: p_i > d_ij 不成立 ({p_i:.2f} > {d_ij:.2f})")
                if not condition2:
                    print(f"   失败原因: P_j*q_ij + d_ij > p_i 不成立 ({left_side:.2f} > {p_i:.2f})")
            print("-" * 60)
        
        # 如果过滤后的列表不为空，则添加到新字典中
        if filtered_list:
            filtered_substitutions[demand_food] = filtered_list
    
    print("=" * 80)
    print("过滤结果统计:")
    print(f"总替代关系数量: {total_count}")
    print(f"保留替代关系数量: {total_count - removed_count}")
    print(f"删除替代关系数量: {removed_count}")
    print(f"保留比例: {(total_count - removed_count)/total_count*100:.1f}%")
    
    # 检查是否有食物完全失去了所有替代关系
    completely_removed_foods = []
    for food in substitutions:
        if food not in filtered_substitutions:
            completely_removed_foods.append(food)
    
    if completely_removed_foods:
        print(f"\n⚠️  以下食物完全失去了所有替代关系: {completely_removed_foods}")
    
    print("=" * 80)
    
    return filtered_substitutions

def calculate_total_shortage(foods, demand_scenarios):
    """
    计算固定采购量（使用weekly_demand_mean）的总缺货量
    """
    print("=" * 80)
    print("固定采购量总缺货量计算")
    print("=" * 80)
    
    num_scenarios = len(demand_scenarios)
    
    # 总缺货量统计
    total_shortage_all_foods = 0
    food_shortage_stats = {}
    
    for food in foods:
        food_shortage_stats[food] = 0
    
    for s in range(num_scenarios):
        for food in foods:
            # 固定采购量
            x_i = weekly_demand_mean[food]
            # 当前场景的需求
            demand = demand_scenarios.iloc[s, list(foods.keys()).index(food)]
            
            # 计算短缺量
            shortage = max(0, demand - x_i)
            
            # 累加总缺货量
            total_shortage_all_foods += shortage
            food_shortage_stats[food] += shortage
    
    print(f"总缺货量（所有食物×所有场景）: {total_shortage_all_foods:.2f} kg")
    print(f"平均每个场景总缺货量: {total_shortage_all_foods / num_scenarios:.2f} kg")
    print()
    
    print("各食物总缺货量:")
    print("-" * 40)
    for food in foods:
        total_shortage = food_shortage_stats[food]
        avg_shortage = total_shortage / num_scenarios
        print(f"{food:15}: 总缺货{total_shortage:8.2f} kg, 平均{avg_shortage:6.2f} kg/场景")
    
    print("=" * 80)
    
    return total_shortage_all_foods

# 简化的版本，只返回总缺货量
def get_total_shortage_only(foods, demand_scenarios):
    """
    只计算总缺货量，不打印详细信息
    """
    num_scenarios = len(demand_scenarios)
    total_shortage = 0
    
    for s in range(num_scenarios):
        for food in foods:
            x_i = weekly_demand_mean[food]
            demand = demand_scenarios.iloc[s, list(foods.keys()).index(food)]
            shortage = max(0, demand - x_i)
            total_shortage += shortage
    
    return total_shortage

def calculate_fixed_purchase_cost(foods, demand_scenarios):
    """
    计算固定采购量（使用weekly_demand_mean）的总成本，包括采购成本、缺货成本和剩余价值
    """
    print("=" * 80)
    print("固定采购量总成本计算（含剩余价值）")
    print("=" * 80)
    
    num_scenarios = len(demand_scenarios)
    
    # 第一阶段成本：采购成本
    first_stage_cost = 0
    for food in foods:
        purchase_quantity = weekly_demand_mean[food]
        first_stage_cost += foods[food]['cost'] * purchase_quantity
    
    print(f"第一阶段采购成本: {first_stage_cost:.2f}")
    
    # 第二阶段成本：缺货成本 + 剩余价值（注意：剩余价值可能是负值）
    shortage_cost_total = 0
    salvage_value_total = 0
    
    for s in range(num_scenarios):
        scenario_shortage_cost = 0
        scenario_salvage_value = 0
        
        for food in foods:
            # 固定采购量
            x_i = weekly_demand_mean[food]
            # 当前场景的需求
            demand = demand_scenarios.iloc[s, list(foods.keys()).index(food)]
            
            # 计算短缺量和剩余量
            shortage = max(0, demand - x_i)
            surplus = max(0, x_i - demand)
            
            # 缺货成本
            shortage_penalty = foods[food]['shortage_penalty']
            scenario_shortage_cost += shortage_penalty * shortage
            
            # 剩余价值（注意：salvage_value是负值，表示处理成本）
            salvage_value = foods[food]['salvage_value']  # 这是负值
            scenario_salvage_value += salvage_value * surplus  # 负值 × 剩余量 = 额外的成本
        
        shortage_cost_total += scenario_shortage_cost
        salvage_value_total += scenario_salvage_value
    
    # 平均第二阶段成本
    avg_shortage_cost = shortage_cost_total / num_scenarios
    avg_salvage_value = salvage_value_total / num_scenarios  # 这是负值
    
    print(f"平均缺货成本: {avg_shortage_cost:.2f}")
    print(f"平均剩余处理成本: {-avg_salvage_value:.2f}")  # 显示为正值便于理解
    print(f"净第二阶段成本: {avg_shortage_cost + avg_salvage_value:.2f}")  # 注意这里是相加
    
    # 总期望成本 = 采购成本 + 缺货成本 + 剩余处理成本
    total_expected_cost = first_stage_cost + avg_shortage_cost - avg_salvage_value
    
    print("=" * 80)
    print(f"固定采购量总期望成本: {total_expected_cost:.2f}")
    print("=" * 80)
    
    return total_expected_cost

# 主函数
if __name__ == "__main__":
    num_scenarios = 4000
    demand_scenarios = generate_demand_scenarios(num_scenarios)
    
    # 检验并过滤替代关系
    filtered_substitutions = check_and_filter_substitutions(foods, substitutions)
    
    # 使用过滤后的替代关系
    substitutions = filtered_substitutions
    
    # 保存需求场景
    save_demand_scenarios_to_csv(demand_scenarios, 'l5demand_scenarios.csv')
    
    # 保存额外信息（使用过滤后的替代关系）
    save_additional_info_to_json(foods, filtered_substitutions, storage_capacity, 'l5additional_info.json')
    
    print("Simulation data generated and saved to 'demand_scenarios.csv' and 'additional_info.json'.")