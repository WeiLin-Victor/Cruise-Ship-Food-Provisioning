# -*- coding: utf-8 -*-

import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import json
import random
from gendata import calculate_total_shortage, calculate_fixed_purchase_cost, weekly_demand_mean

def read_demand_scenarios(filename, num_scenarios=None, random_seed=42):
    """
    读取需求场景，可随机抽取指定数量的场景
    
    参数:
    filename: 场景文件路径
    num_scenarios: 需要抽取的场景数量，如果为None则读取所有场景
    random_seed: 随机种子，确保结果可重现
    """
    all_scenarios = pd.read_csv(filename)
    
    if num_scenarios is None or num_scenarios >= len(all_scenarios):
        return all_scenarios
    
    # 设置随机种子确保结果可重现
    if random_seed is not None:
        random.seed(random_seed)
    
    # 随机抽取指定数量的场景
    selected_indices = random.sample(range(len(all_scenarios)), num_scenarios)
    selected_scenarios = all_scenarios.iloc[selected_indices].reset_index(drop=True)
    
    print(f"从 {len(all_scenarios)} 个总场景中随机抽取了 {num_scenarios} 个场景")
    return selected_scenarios


# 读取额外信息
def read_additional_info(filename):
    with open(filename, 'r') as f:
        data = json.load(f)
    return data['foods'], data['substitutions'], data['storage_capacity']

def build_optimization_model(foods, substitutions, storage_capacity, demand_scenarios):
    """构建修正后的优化模型"""
    num_scenarios = len(demand_scenarios)
    model = gp.Model("CruiseShipFoodProvisioning_Corrected")
    
    # 第一阶段变量：采购决策
    x = model.addVars(foods.keys(), vtype=GRB.CONTINUOUS, name="x", lb=0)
    xk = model.addVars(foods.keys(), storage_capacity.keys(), vtype=GRB.CONTINUOUS, name="xk", lb=0)
    
    # 第二阶段变量：只定义有效的替代关系
    u = {}  # u[i,j,s]: 用食品j替代食品i的数量
    for i in foods:
        if i in substitutions:
            for sub in substitutions[i]:
                j = sub['food']
                for s in range(num_scenarios):
                    u_key = (i, j, s)
                    u[u_key] = model.addVar(vtype=GRB.CONTINUOUS, name=f"u_{i}_{j}_{s}", lb=0)
    
    w = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.CONTINUOUS, name="w", lb=0)
    
    # 辅助变量用于线性化max函数
    M = 1e7  # 大M常数
    a_vars = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.BINARY, name="a")
    beta_vars = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.BINARY, name="beta")
    S_b = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.CONTINUOUS, name="S_b", lb=0)
    R_b = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.CONTINUOUS, name="R_b", lb=0)
    
    # 目标函数：最小化总期望成本
    first_stage_cost = gp.quicksum(foods[i]['cost'] * xk[i, k] for i in foods for k in storage_capacity)
    second_stage_cost = 0
    
    for s in range(num_scenarios):
        scenario_cost = 0
        for i in foods:
            demand = demand_scenarios.iloc[s][i] if i in demand_scenarios.columns else demand_scenarios.iloc[s, list(foods.keys()).index(i)]
            
            # 线性化初始短缺和剩余计算
            model.addConstr(S_b[i, s] >= demand - x[i], f"shortage_lb_{i}_{s}")
            model.addConstr(S_b[i, s] <= demand - x[i] + M * (1 - a_vars[i, s]), f"shortage_ub1_{i}_{s}")
            model.addConstr(S_b[i, s] <= M * a_vars[i, s], f"shortage_ub2_{i}_{s}")
            
            model.addConstr(R_b[i, s] >= x[i] - demand, f"surplus_lb_{i}_{s}")
            model.addConstr(R_b[i, s] <= x[i] - demand + M * (1 - beta_vars[i, s]), f"surplus_ub1_{i}_{s}")
            model.addConstr(R_b[i, s] <= M * beta_vars[i, s], f"surplus_ub2_{i}_{s}")
            
            model.addConstr(a_vars[i, s] + beta_vars[i, s] == 1, f"complementary_{i}_{s}")
            
            # 计算从食品i出发的替代总量
            substitution_from_i = gp.quicksum(
                u[i, j, s] for j in foods 
                if (i, j, s) in u
            )
            
            # 净缺货量（初始缺货 - 被替代的量）
            net_shortage = S_b[i, s] - substitution_from_i
            model.addConstr(net_shortage >= 0, f"net_shortage_nonneg_{i}_{s}")
            
            # 缺货惩罚成本（基于净缺货）
            scenario_cost += foods[i]['shortage_penalty'] * net_shortage
            
            # 替代惩罚成本
            if i in substitutions:
                for sub in substitutions[i]:
                    j = sub['food']
                    if (i, j, s) in u:
                        scenario_cost += sub['penalty'] * u[i, j, s]
            
            # 剩余价值（负成本）
            scenario_cost -= foods[i]['salvage_value'] * w[i, s]
        
        second_stage_cost += scenario_cost
    
    # 总目标函数
    total_cost = first_stage_cost + second_stage_cost / num_scenarios
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # 约束条件
    
    # 1. 存储容量约束
    for k in storage_capacity:
        model.addConstr(
            gp.quicksum(foods[i]['volume'] * xk[i, k] for i in foods) <= storage_capacity[k],
            f"storage_capacity_{k}"
        )
    
    # 2. 采购量平衡约束
    for i in foods:
        model.addConstr(
            x[i] == gp.quicksum(xk[i, k] for k in storage_capacity),
            f"purchase_balance_{i}"
        )
    
    # 3. 第二阶段约束
    for s in range(num_scenarios):
        for i in foods:
            # 约束3.1: 替代量不超过初始缺货量
            substitution_from_i = gp.quicksum(
                u[i, j, s] for j in foods 
                if (i, j, s) in u
            )
            model.addConstr(
                substitution_from_i <= S_b[i, s],
                f"substitution_limit_{i}_{s}"
            )
            
            # 约束3.2: 作为替代品被消耗的量不超过初始剩余量
            substitution_to_i = gp.quicksum(
                sub['calories_ratio'] * u[j, i, s] 
                for j in foods 
                if j in substitutions
                for sub in substitutions[j] 
                if sub['food'] == i and (j, i, s) in u
            )
            model.addConstr(
                substitution_to_i <= R_b[i, s],
                f"surplus_usage_limit_{i}_{s}"
            )
            # 约束3.2: 服务水平约束 - 替代量不超过需求量的5%
            demand = demand_scenarios.iloc[s][i] if i in demand_scenarios.columns else demand_scenarios.iloc[s, list(foods.keys()).index(i)]
            model.addConstr(
                substitution_from_i <= foods[i]['service_level'] * demand,
                f"service_level_limit_{i}_{s}"
            )
            # 约束3.3: 最终剩余量平衡
            model.addConstr(
                w[i, s] == R_b[i, s] - substitution_to_i + substitution_from_i,
                f"inventory_balance_{i}_{s}"
            )
    
    return model, x, xk, u, w, S_b, R_b

def analyze_solution(model, foods, substitutions, demand_scenarios, x, xk, u, w, S_b, R_b):
    """分析优化结果"""
    if model.status != gp.GRB.OPTIMAL:
        print("未找到最优解")
        return None, 0, 0, 0
    
    num_scenarios = len(demand_scenarios)
    
    print("\n" + "=" * 80)
    print("优化结果分析")
    print("=" * 80)
    
    # 统计缺货和替代情况
    product_stats = {}
    total_initial_shortage = 0
    total_final_shortage = 0
    total_substitution = 0
    
    for i in foods:
        initial_shortage = sum(S_b[i, s].X for s in range(num_scenarios))
        substitution_out = sum(u[i, j, s].X for j in foods for s in range(num_scenarios) if (i, j, s) in u)
        final_shortage = max(0, initial_shortage - substitution_out)
        
        total_initial_shortage += initial_shortage
        total_final_shortage += final_shortage
        total_substitution += substitution_out
        
        product_stats[i] = {
            'purchase': x[i].X,
            'initial_shortage': initial_shortage,
            'substitution_out': substitution_out,
            'final_shortage': final_shortage,
            'reduction': initial_shortage - final_shortage
        }
    
    # 打印产品统计
    print(f"{'产品':<15} {'采购量':>10} {'初始缺货':>10} {'替代量':>10} {'最终缺货':>10} {'减少量':>10}")
    print("-" * 75)
    for product, stats in product_stats.items():
        print(f"{product:<15} {stats['purchase']:>10.2f} {stats['initial_shortage']:>10.2f} "
              f"{stats['substitution_out']:>10.2f} {stats['final_shortage']:>10.2f} {stats['reduction']:>10.2f}")
    
    print("-" * 75)
    print(f"{'总计':<15} {'':>10} {total_initial_shortage:>10.2f} {total_substitution:>10.2f} "
          f"{total_final_shortage:>10.2f} {total_initial_shortage-total_final_shortage:>10.2f}")
    
    return product_stats, total_initial_shortage, total_final_shortage, total_substitution

def calculate_cost_breakdown(model, foods, substitutions, demand_scenarios, x, xk, u, w, S_b, R_b):
    """计算成本分解"""
    if model.status != gp.GRB.OPTIMAL:
        return None
    
    num_scenarios = len(demand_scenarios)
    
    # 第一阶段成本：采购成本
    purchase_cost = 0
    for i in foods:
        for k in range(3):
            purchase_cost += foods[i]['cost'] * xk[i, k].X
    
    # 第二阶段成本分解
    shortage_penalty_cost = 0
    substitution_penalty_cost = 0
    salvage_value_total = 0
    
    for s in range(num_scenarios):
        for i in foods:
            # 净缺货惩罚
            substitution_from_i = sum(u[i, j, s].X for j in foods if (i, j, s) in u)
            net_shortage = max(0, S_b[i, s].X - substitution_from_i)
            shortage_penalty_cost += foods[i]['shortage_penalty'] * net_shortage
            
            # 替代惩罚
            if i in substitutions:
                for sub in substitutions[i]:
                    j = sub['food']
                    if (i, j, s) in u:
                        substitution_penalty_cost += sub['penalty'] * u[i, j, s].X
            
            # 剩余价值
            salvage_value_total += foods[i]['salvage_value'] * w[i, s].X
    
    # 计算平均值
    avg_shortage_penalty = shortage_penalty_cost / num_scenarios
    avg_substitution_penalty = substitution_penalty_cost / num_scenarios
    avg_salvage_value = salvage_value_total / num_scenarios
    avg_second_stage_cost = avg_shortage_penalty + avg_substitution_penalty - avg_salvage_value
    
    total_cost = purchase_cost + avg_second_stage_cost
    
    cost_breakdown = {
        'total_cost': total_cost,
        'purchase_cost': purchase_cost,
        'second_stage_cost': avg_second_stage_cost,
        'shortage_penalty_cost': avg_shortage_penalty,
        'substitution_penalty_cost': avg_substitution_penalty,
        'salvage_value': avg_salvage_value
    }
    
    return cost_breakdown

def print_cost_breakdown(cost_breakdown):
    """打印成本分解结果"""
    print("\n" + "=" * 80)
    print("成本分解分析")
    print("=" * 80)
    
    print("优化策略成本分解:")
    print("-" * 50)
    print(f"第一阶段采购成本: {cost_breakdown['purchase_cost']:.2f}")
    print(f"第二阶段期望成本: {cost_breakdown['second_stage_cost']:.2f}")
    print(f"  其中：")
    print(f"  - 缺货惩罚成本: {cost_breakdown['shortage_penalty_cost']:.2f}")
    print(f"  - 替代惩罚成本: {cost_breakdown['substitution_penalty_cost']:.2f}")
    print(f"  - 剩余价值: {cost_breakdown['salvage_value']:.2f}")
    print(f"总期望成本: {cost_breakdown['total_cost']:.2f}")
    
    # 计算成本构成比例
    print(f"\n成本构成比例:")
    print("-" * 50)
    total = cost_breakdown['total_cost']
    print(f"采购成本占比: {cost_breakdown['purchase_cost']/total*100:.1f}%")
    print(f"缺货惩罚占比: {cost_breakdown['shortage_penalty_cost']/total*100:.1f}%")
    print(f"替代惩罚占比: {cost_breakdown['substitution_penalty_cost']/total*100:.1f}%")
    print(f"剩余价值占比: {cost_breakdown['salvage_value']/total*100:.1f}%")






def run_experiment_for_number(num):
    """为特定数字运行实验"""
    # 参数设置
    NUM_REPETITIONS = 20  # 重复计算次数
    NUM_SCENARIOS = 80    # 每次抽取的场景数
    RANDOM_SEED_BASE = 42 # 随机种子基准
    
    # 根据数字生成文件名
    demand_file = f'd{num}demand_scenarios.csv'
    info_file = f'd{num}additional_info.json'
    
    print(f"\n{'='*60}")
    print(f"正在处理数据 {num}: {demand_file}, {info_file}")
    print(f"{'='*60}")
    
    # 存储统计结果
    purchase_summary = {}
    shortage_summary = {}
    substitution_summary = {}
    final_shortage_summary = {}
    compensated_shortage_summary = {}
    cost_summary = {
        'purchase_cost': [], 
        'shortage_cost': [], 
        'substitution_cost': [],
        'salvage_value': [],
        'total_cost': []
    }
    
    for repetition in range(NUM_REPETITIONS):
        # 每次使用不同的随机种子
        current_seed = RANDOM_SEED_BASE + repetition
        
        try:
            # 读取数据
            demand_scenarios = read_demand_scenarios(
                demand_file, 
                num_scenarios=NUM_SCENARIOS,
                random_seed=current_seed
            )
            
            foods, substitutions, storage_capacity = read_additional_info(info_file)
            
            # 构建并求解模型
            model, x, xk, u, w, S_b, R_b = build_optimization_model(
                foods, substitutions, storage_capacity, demand_scenarios
            )
            
            model.setParam('OutputFlag', 0)  # 关闭输出
            model.optimize()
            
            if model.status == gp.GRB.OPTIMAL:
                # 统计各产品量
                for i in foods:
                    if i not in purchase_summary:
                        purchase_summary[i] = []
                        shortage_summary[i] = []
                        substitution_summary[i] = []
                        final_shortage_summary[i] = []
                        compensated_shortage_summary[i] = []
                    
                    purchase_summary[i].append(x[i].X)
                    
                    # 计算初始缺货量
                    total_shortage = sum(S_b[i, s].X for s in range(len(demand_scenarios)))
                    shortage_summary[i].append(total_shortage)
                    
                    # 计算替代量
                    total_substitution = sum(u[i, j, s].X for j in foods for s in range(len(demand_scenarios)) if (i, j, s) in u)
                    substitution_summary[i].append(total_substitution)
                    
                    # 计算最终缺货量（初始缺货 - 被替代的量）
                    final_shortage = max(0, total_shortage - total_substitution)
                    final_shortage_summary[i].append(final_shortage)
                    
                    # 计算被替代补偿的缺货量
                    compensated_shortage = min(total_shortage, total_substitution)
                    compensated_shortage_summary[i].append(compensated_shortage)
                
                # 修正成本统计 - 包含所有成本成分
                purchase_cost = sum(foods[i]['cost'] * xk[i, k].X for i in foods for k in storage_capacity)
                
                shortage_penalty_cost = 0
                substitution_penalty_cost = 0
                salvage_value_total = 0
                
                for s in range(len(demand_scenarios)):
                    for i in foods:
                        # 净缺货惩罚成本
                        substitution_from_i = sum(u[i, j, s].X for j in foods if (i, j, s) in u)
                        net_shortage = max(0, S_b[i, s].X - substitution_from_i)
                        shortage_penalty_cost += foods[i]['shortage_penalty'] * net_shortage
                        
                        # 替代惩罚成本
                        if i in substitutions:
                            for sub in substitutions[i]:
                                j = sub['food']
                                if (i, j, s) in u:
                                    substitution_penalty_cost += sub['penalty'] * u[i, j, s].X
                        
                        # 残余价值（注意：残余价值是收入，所以是负成本）
                        salvage_value_total += foods[i]['salvage_value'] * w[i, s].X
                
                # 计算期望成本（除以场景数）
                avg_shortage_cost = shortage_penalty_cost / len(demand_scenarios)
                avg_substitution_cost = substitution_penalty_cost / len(demand_scenarios)
                avg_salvage_value = salvage_value_total / len(demand_scenarios)
                
                # 总成本 = 采购成本 + 缺货惩罚成本 + 替代惩罚成本 - 残余价值
                total_cost = purchase_cost + avg_shortage_cost + avg_substitution_cost - avg_salvage_value
                
                cost_summary['purchase_cost'].append(purchase_cost)
                cost_summary['shortage_cost'].append(avg_shortage_cost)
                cost_summary['substitution_cost'].append(avg_substitution_cost)
                cost_summary['salvage_value'].append(avg_salvage_value)
                cost_summary['total_cost'].append(total_cost)
            
            del model
            
        except FileNotFoundError as e:
            print(f"文件未找到: {e}")
            return None
        except Exception as e:
            print(f"处理数据 {num} 时出现错误: {e}")
            return None
    
    # 计算平均值
    avg_costs = {
        'data_number': num,
        'purchase_cost': sum(cost_summary['purchase_cost']) / len(cost_summary['purchase_cost']),
        'shortage_cost': sum(cost_summary['shortage_cost']) / len(cost_summary['shortage_cost']),
        'substitution_cost': sum(cost_summary['substitution_cost']) / len(cost_summary['substitution_cost']),
        'salvage_value': sum(cost_summary['salvage_value']) / len(cost_summary['salvage_value']),
        'total_cost': sum(cost_summary['total_cost']) / len(cost_summary['total_cost'])
    }
    
    # 打印结果
    print(f"\n数据 {num} 的结果:")
    print(f"采购成本: {avg_costs['purchase_cost']:.2f}")
    print(f"缺货惩罚成本: {avg_costs['shortage_cost']:.2f}")
    print(f"替代惩罚成本: {avg_costs['substitution_cost']:.2f}")
    print(f"残余价值: {avg_costs['salvage_value']:.2f}")
    print(f"总成本: {avg_costs['total_cost']:.2f}")
    
    # 成本构成分析
    total = avg_costs['total_cost']
    if total > 0:
        print(f"\n成本构成分析:")
        print(f"采购成本占比: {avg_costs['purchase_cost']/total*100:.1f}%")
        print(f"缺货惩罚占比: {avg_costs['shortage_cost']/total*100:.1f}%")
        print(f"替代惩罚占比: {avg_costs['substitution_cost']/total*100:.1f}%")
        print(f"残余价值占比: {avg_costs['salvage_value']/total*100:.1f}%")
    
    return avg_costs

# 主执行流程
if __name__ == "__main__":
    # 测试数据范围：2-8
    data_numbers = range(1, 6)  # 2,3,4,5,6,7,8
    
    # 存储所有结果
    all_results = []
    
    for num in data_numbers:
        result = run_experiment_for_number(num)
        if result is not None:
            all_results.append(result)
    
    # 创建DataFrame并保存到Excel
    if all_results:
        df = pd.DataFrame(all_results)
        
        # 设置数据编号为索引
        df.set_index('data_number', inplace=True)
        
        # 添加成本构成百分比列
        df['purchase_cost_pct'] = df['purchase_cost'] / df['total_cost'] * 100
        df['shortage_cost_pct'] = df['shortage_cost'] / df['total_cost'] * 100
        df['substitution_cost_pct'] = df['substitution_cost'] / df['total_cost'] * 100
        df['salvage_value_pct'] = df['salvage_value'] / df['total_cost'] * 100
        
        # 重新排列列的顺序
        columns_order = [
            'purchase_cost', 'purchase_cost_pct',
            'shortage_cost', 'shortage_cost_pct', 
            'substitution_cost', 'substitution_cost_pct',
            'salvage_value', 'salvage_value_pct',
            'total_cost'
        ]
        df = df[columns_order]
        
        # 保存到Excel文件
        excel_filename = 'd_analysis_results.xlsx'
        df.to_excel(excel_filename, float_format='%.2f')
        
        print(f"\n{'='*60}")
        print(f"所有结果已保存到: {excel_filename}")
        print(f"{'='*60}")
        
        # 打印汇总表格
        print("\n成本分析汇总表:")
        print(df.round(2))
        
        # 创建详细报告
        with pd.ExcelWriter(excel_filename, engine='openpyxl', mode='a') as writer:
            # 添加详细分析工作表
            summary_df = pd.DataFrame({
                '指标': ['最低总成本', '最高总成本', '平均总成本', '总成本标准差'],
                '数值': [
                    df['total_cost'].min(),
                    df['total_cost'].max(), 
                    df['total_cost'].mean(),
                    df['total_cost'].std()
                ]
            })
            summary_df.to_excel(writer, sheet_name='统计摘要', index=False)
            
            # 添加趋势分析工作表
            trend_analysis = df[['total_cost']].copy()
            trend_analysis['变化率(%)'] = trend_analysis['total_cost'].pct_change() * 100
            trend_analysis.to_excel(writer, sheet_name='趋势分析')
            
    else:
        print("没有成功处理任何数据文件。")