# -*- coding: utf-8 -*-
"""
Created on Mon Oct 13 22:07:33 2025

@author: 孙潍霖
"""

# -*- coding: utf-8 -*-

import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import json
import random
from gendata import calculate_total_shortage, calculate_fixed_purchase_cost, weekly_demand_mean

def read_demand_scenarios(filename, num_scenarios=None, random_seed=42):
    """
    读取需求场景，可随机抽取指定数量的场景
    
    参数:
    filename: 场景文件路径
    num_scenarios: 需要抽取的场景数量，如果为None则读取所有场景
    random_seed: 随机种子，确保结果可重现
    """
    all_scenarios = pd.read_csv(filename)
    
    if num_scenarios is None or num_scenarios >= len(all_scenarios):
        return all_scenarios
    
    # 设置随机种子确保结果可重现
    if random_seed is not None:
        random.seed(random_seed)
    
    # 随机抽取指定数量的场景
    selected_indices = random.sample(range(len(all_scenarios)), num_scenarios)
    selected_scenarios = all_scenarios.iloc[selected_indices].reset_index(drop=True)
    
    print(f"从 {len(all_scenarios)} 个总场景中随机抽取了 {num_scenarios} 个场景")
    return selected_scenarios

# 读取额外信息
def read_additional_info(filename):
    with open(filename, 'r') as f:
        data = json.load(f)
    return data['foods'], data['substitutions'], data['storage_capacity']

def build_optimization_model(foods, substitutions, storage_capacity, demand_scenarios):
    """构建修正后的优化模型"""
    num_scenarios = len(demand_scenarios)
    model = gp.Model("CruiseShipFoodProvisioning_Corrected")
    
    # 第一阶段变量：采购决策
    x = model.addVars(foods.keys(), vtype=GRB.CONTINUOUS, name="x", lb=0)
    xk = model.addVars(foods.keys(), storage_capacity.keys(), vtype=GRB.CONTINUOUS, name="xk", lb=0)
    
    # 第二阶段变量：只定义有效的替代关系
    u = {}  # u[i,j,s]: 用食品j替代食品i的数量
    for i in foods:
        if i in substitutions:
            for sub in substitutions[i]:
                j = sub['food']
                for s in range(num_scenarios):
                    u_key = (i, j, s)
                    u[u_key] = model.addVar(vtype=GRB.CONTINUOUS, name=f"u_{i}_{j}_{s}", lb=0)
    
    w = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.CONTINUOUS, name="w", lb=0)
    
    # 辅助变量用于线性化max函数
    M = 1e7  # 大M常数
    a_vars = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.BINARY, name="a")
    beta_vars = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.BINARY, name="beta")
    S_b = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.CONTINUOUS, name="S_b", lb=0)
    R_b = model.addVars(foods.keys(), range(num_scenarios), vtype=GRB.CONTINUOUS, name="R_b", lb=0)
    
    # 目标函数：最小化总期望成本
    first_stage_cost = gp.quicksum(foods[i]['cost'] * xk[i, k] for i in foods for k in storage_capacity)
    second_stage_cost = 0
    
    for s in range(num_scenarios):
        scenario_cost = 0
        for i in foods:
            demand = demand_scenarios.iloc[s][i] if i in demand_scenarios.columns else demand_scenarios.iloc[s, list(foods.keys()).index(i)]
            
            # 线性化初始短缺和剩余计算
            model.addConstr(S_b[i, s] >= demand - x[i], f"shortage_lb_{i}_{s}")
            model.addConstr(S_b[i, s] <= demand - x[i] + M * (1 - a_vars[i, s]), f"shortage_ub1_{i}_{s}")
            model.addConstr(S_b[i, s] <= M * a_vars[i, s], f"shortage_ub2_{i}_{s}")
            
            model.addConstr(R_b[i, s] >= x[i] - demand, f"surplus_lb_{i}_{s}")
            model.addConstr(R_b[i, s] <= x[i] - demand + M * (1 - beta_vars[i, s]), f"surplus_ub1_{i}_{s}")
            model.addConstr(R_b[i, s] <= M * beta_vars[i, s], f"surplus_ub2_{i}_{s}")
            
            model.addConstr(a_vars[i, s] + beta_vars[i, s] == 1, f"complementary_{i}_{s}")
            
            # 计算从食品i出发的替代总量
            substitution_from_i = gp.quicksum(
                u[i, j, s] for j in foods 
                if (i, j, s) in u
            )
            
            # 净缺货量（初始缺货 - 被替代的量）
            net_shortage = S_b[i, s] - substitution_from_i
            model.addConstr(net_shortage >= 0, f"net_shortage_nonneg_{i}_{s}")
            
            # 缺货惩罚成本（基于净缺货）
            scenario_cost += foods[i]['shortage_penalty'] * net_shortage
            
            # 替代惩罚成本
            if i in substitutions:
                for sub in substitutions[i]:
                    j = sub['food']
                    if (i, j, s) in u:
                        scenario_cost += sub['penalty'] * u[i, j, s]
            
            # 剩余价值（负成本）
            scenario_cost -= foods[i]['salvage_value'] * w[i, s]
        
        second_stage_cost += scenario_cost
    
    # 总目标函数
    total_cost = first_stage_cost + second_stage_cost / num_scenarios
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # 约束条件
    
    # 1. 存储容量约束
    for k in storage_capacity:
        model.addConstr(
            gp.quicksum(foods[i]['volume'] * xk[i, k] for i in foods) <= storage_capacity[k],
            f"storage_capacity_{k}"
        )
    
    # 2. 采购量平衡约束
    for i in foods:
        model.addConstr(
            x[i] == gp.quicksum(xk[i, k] for k in storage_capacity),
            f"purchase_balance_{i}"
        )
    
    # 3. 第二阶段约束
    for s in range(num_scenarios):
        for i in foods:
            # 约束3.1: 替代量不超过初始缺货量
            substitution_from_i = gp.quicksum(
                u[i, j, s] for j in foods 
                if (i, j, s) in u
            )
            model.addConstr(
                substitution_from_i <= S_b[i, s],
                f"substitution_limit_{i}_{s}"
            )
            
            # 约束3.2: 作为替代品被消耗的量不超过初始剩余量
            substitution_to_i = gp.quicksum(
                sub['calories_ratio'] * u[j, i, s] 
                for j in foods 
                if j in substitutions
                for sub in substitutions[j] 
                if sub['food'] == i and (j, i, s) in u
            )
            model.addConstr(
                substitution_to_i <= R_b[i, s],
                f"surplus_usage_limit_{i}_{s}"
            )
            # 约束3.2: 服务水平约束 - 替代量不超过需求量的5%
            demand = demand_scenarios.iloc[s][i] if i in demand_scenarios.columns else demand_scenarios.iloc[s, list(foods.keys()).index(i)]
            model.addConstr(
                substitution_from_i <= foods[i]['service_level'] * demand,
                f"service_level_limit_{i}_{s}"
            )
            # 约束3.3: 最终剩余量平衡
            model.addConstr(
                w[i, s] == R_b[i, s] - substitution_to_i + substitution_from_i,
                f"inventory_balance_{i}_{s}"
            )
    
    return model, x, xk, u, w, S_b, R_b

def run_experiment_for_number(num):
    """为特定数字运行实验"""
    # 参数设置
    NUM_REPETITIONS = 20  # 重复计算次数
    NUM_SCENARIOS = 80    # 每次抽取的场景数
    RANDOM_SEED_BASE = 42 # 随机种子基准
    
    # 根据数字生成文件名
    demand_file = f'l{num}demand_scenarios.csv'
    info_file = f'l{num}additional_info.json'
    
    print(f"\n{'='*60}")
    print(f"正在处理数据 {num}: {demand_file}, {info_file}")
    print(f"{'='*60}")
    
    # 存储统计结果
    purchase_summary = {}
    shortage_summary = {}
    substitution_summary = {}
    final_shortage_summary = {}
    compensated_shortage_summary = {}
    substitution_pair_summary = {}  # 新增：存储替代对统计
    cost_summary = {
        'purchase_cost': [], 
        'shortage_cost': [], 
        'substitution_cost': [],
        'salvage_value': [],
        'total_cost': []
    }
    
    for repetition in range(NUM_REPETITIONS):
        # 每次使用不同的随机种子
        current_seed = RANDOM_SEED_BASE + repetition
        
        try:
            # 读取数据
            demand_scenarios = read_demand_scenarios(
                demand_file, 
                num_scenarios=NUM_SCENARIOS,
                random_seed=current_seed
            )
            
            foods, substitutions, storage_capacity = read_additional_info(info_file)
            
            # 构建并求解模型
            model, x, xk, u, w, S_b, R_b = build_optimization_model(
                foods, substitutions, storage_capacity, demand_scenarios
            )
            
            model.setParam('OutputFlag', 0)  # 关闭输出
            model.optimize()
            
            if model.status == gp.GRB.OPTIMAL:
                # 统计各产品量
                for i in foods:
                    if i not in purchase_summary:
                        purchase_summary[i] = []
                        shortage_summary[i] = []
                        substitution_summary[i] = []
                        final_shortage_summary[i] = []
                        compensated_shortage_summary[i] = []
                    
                    purchase_summary[i].append(x[i].X)
                    
                    # 计算初始缺货量
                    total_shortage = sum(S_b[i, s].X for s in range(len(demand_scenarios)))
                    shortage_summary[i].append(total_shortage)
                    
                    # 计算替代量
                    total_substitution = sum(u[i, j, s].X for j in foods for s in range(len(demand_scenarios)) if (i, j, s) in u)
                    substitution_summary[i].append(total_substitution)
                    
                    # 计算最终缺货量（初始缺货 - 被替代的量）
                    final_shortage = max(0, total_shortage - total_substitution)
                    final_shortage_summary[i].append(final_shortage)
                    
                    # 计算被替代补偿的缺货量
                    compensated_shortage = min(total_shortage, total_substitution)
                    compensated_shortage_summary[i].append(compensated_shortage)
                
                # 统计替代对信息
                for (i, j, s) in u:
                    if (i, j) not in substitution_pair_summary:
                        substitution_pair_summary[(i, j)] = []
                    substitution_pair_summary[(i, j)].append(u[i, j, s].X)
                
                # 修正成本统计 - 包含所有成本成分
                purchase_cost = sum(foods[i]['cost'] * xk[i, k].X for i in foods for k in storage_capacity)
                
                shortage_penalty_cost = 0
                substitution_penalty_cost = 0
                salvage_value_total = 0
                
                for s in range(len(demand_scenarios)):
                    for i in foods:
                        # 净缺货惩罚成本
                        substitution_from_i = sum(u[i, j, s].X for j in foods if (i, j, s) in u)
                        net_shortage = max(0, S_b[i, s].X - substitution_from_i)
                        shortage_penalty_cost += foods[i]['shortage_penalty'] * net_shortage
                        
                        # 替代惩罚成本
                        if i in substitutions:
                            for sub in substitutions[i]:
                                j = sub['food']
                                if (i, j, s) in u:
                                    substitution_penalty_cost += sub['penalty'] * u[i, j, s].X
                        
                        # 残余价值（注意：残余价值是收入，所以是负成本）
                        salvage_value_total += foods[i]['salvage_value'] * w[i, s].X
                
                # 计算期望成本（除以场景数）
                avg_shortage_cost = shortage_penalty_cost / len(demand_scenarios)
                avg_substitution_cost = substitution_penalty_cost / len(demand_scenarios)
                avg_salvage_value = salvage_value_total / len(demand_scenarios)
                
                # 总成本 = 采购成本 + 缺货惩罚成本 + 替代惩罚成本 - 残余价值
                total_cost = purchase_cost + avg_shortage_cost + avg_substitution_cost - avg_salvage_value
                
                cost_summary['purchase_cost'].append(purchase_cost)
                cost_summary['shortage_cost'].append(avg_shortage_cost)
                cost_summary['substitution_cost'].append(avg_substitution_cost)
                cost_summary['salvage_value'].append(avg_salvage_value)
                cost_summary['total_cost'].append(total_cost)
            
            del model
            
        except FileNotFoundError as e:
            print(f"文件未找到: {e}")
            return None, None, None
        except Exception as e:
            print(f"处理数据 {num} 时出现错误: {e}")
            return None, None, None
    
    # 计算成本平均值
    avg_costs = {
        'data_number': num,
        'purchase_cost': sum(cost_summary['purchase_cost']) / len(cost_summary['purchase_cost']),
        'shortage_cost': sum(cost_summary['shortage_cost']) / len(cost_summary['shortage_cost']),
        'substitution_cost': sum(cost_summary['substitution_cost']) / len(cost_summary['substitution_cost']),
        'salvage_value': sum(cost_summary['salvage_value']) / len(cost_summary['salvage_value']),
        'total_cost': sum(cost_summary['total_cost']) / len(cost_summary['total_cost'])
    }
    
    # 计算缺货和替代统计
    shortage_stats = {}
    for product in purchase_summary:
        shortage_stats[product] = {
            'avg_purchase': sum(purchase_summary[product]) / (len(purchase_summary[product])),
            'avg_initial_shortage': sum(shortage_summary[product]) / (len(shortage_summary[product])*len(demand_scenarios)),
            'avg_substitution': sum(substitution_summary[product]) / (len(substitution_summary[product])*len(demand_scenarios)),
            'avg_final_shortage': sum(final_shortage_summary[product]) / (len(final_shortage_summary[product])*len(demand_scenarios)),
            'avg_compensated': sum(compensated_shortage_summary[product]) / (len(compensated_shortage_summary[product])*len(demand_scenarios)),
            'compensation_rate': (sum(compensated_shortage_summary[product]) / sum(shortage_summary[product]) * 100) 
                                if sum(shortage_summary[product]) > 0 else 0
        }
    
    # 计算替代对统计
    substitution_pair_stats = {}
    for (i, j) in substitution_pair_summary:
        substitution_pair_stats[(i, j)] = {
            'avg_substitution': sum(substitution_pair_summary[(i, j)]) / len(substitution_pair_summary[(i, j)]),
            'total_substitution': sum(substitution_pair_summary[(i, j)]),
            'occurrence_rate': (len([x for x in substitution_pair_summary[(i, j)] if x > 0]) / 
                              len(substitution_pair_summary[(i, j)])) * 100
        }
    
    # 打印结果
    print(f"\n数据 {num} 的结果:")
    print(f"采购成本: {avg_costs['purchase_cost']:.2f}")
    print(f"缺货惩罚成本: {avg_costs['shortage_cost']:.2f}")
    print(f"替代惩罚成本: {avg_costs['substitution_cost']:.2f}")
    print(f"残余价值: {avg_costs['salvage_value']:.2f}")
    print(f"总成本: {avg_costs['total_cost']:.2f}")
    
    # 成本构成分析
    total = avg_costs['total_cost']
    if total > 0:
        print(f"\n成本构成分析:")
        print(f"采购成本占比: {avg_costs['purchase_cost']/total*100:.1f}%")
        print(f"缺货惩罚占比: {avg_costs['shortage_cost']/total*100:.1f}%")
        print(f"替代惩罚占比: {avg_costs['substitution_cost']/total*100:.1f}%")
        print(f"残余价值占比: {avg_costs['salvage_value']/total*100:.1f}%")
    
    return avg_costs, shortage_stats, substitution_pair_stats

# 主执行流程
if __name__ == "__main__":
    # 测试数据范围：1-6
    data_numbers = range(1, 6)

    # 存储所有结果
    all_cost_results = []
    all_shortage_results = []
    all_substitution_pair_results = []
    
    for num in data_numbers:
        cost_result, shortage_stats, substitution_pair_stats = run_experiment_for_number(num)
        if cost_result is not None:
            all_cost_results.append(cost_result)
            
            # 将缺货统计转换为DataFrame格式
            for product, stats in shortage_stats.items():
                stats['data_number'] = num
                stats['product'] = product
                all_shortage_results.append(stats.copy())
            
            # 将替代对统计转换为DataFrame格式
            for (i, j), stats in substitution_pair_stats.items():
                stats['data_number'] = num
                stats['from_product'] = i
                stats['to_product'] = j
                all_substitution_pair_results.append(stats.copy())
    
    # 保存结果到Excel文件
    if all_cost_results:
        # 创建Excel写入器
        excel_filename = 'laranalysis_results.xlsx'
        
        with pd.ExcelWriter(excel_filename, engine='openpyxl') as writer:
            
            # 1. 成本分析结果
            cost_df = pd.DataFrame(all_cost_results)
            cost_df.set_index('data_number', inplace=True)
            
            # 添加成本构成百分比列
            cost_df['purchase_cost_pct'] = cost_df['purchase_cost'] / cost_df['total_cost'] * 100
            cost_df['shortage_cost_pct'] = cost_df['shortage_cost'] / cost_df['total_cost'] * 100
            cost_df['substitution_cost_pct'] = cost_df['substitution_cost'] / cost_df['total_cost'] * 100
            cost_df['salvage_value_pct'] = cost_df['salvage_value'] / cost_df['total_cost'] * 100
            
            # 重新排列列的顺序
            cost_columns_order = [
                'purchase_cost', 'purchase_cost_pct',
                'shortage_cost', 'shortage_cost_pct', 
                'substitution_cost', 'substitution_cost_pct',
                'salvage_value', 'salvage_value_pct',
                'total_cost'
            ]
            cost_df = cost_df[cost_columns_order]
            cost_df.to_excel(writer, sheet_name='成本分析', float_format='%.2f')
            
            # 2. 缺货分析结果
            shortage_df = pd.DataFrame(all_shortage_results)
            shortage_df = shortage_df[[
                'data_number', 'product', 'avg_purchase', 'avg_initial_shortage', 
                'avg_substitution', 'avg_final_shortage', 'avg_compensated', 'compensation_rate'
            ]]
            shortage_df.to_excel(writer, sheet_name='缺货分析', index=False, float_format='%.2f')
            
            # 3. 替代对分析结果
            substitution_df = pd.DataFrame(all_substitution_pair_results)
            substitution_df = substitution_df[[
                'data_number', 'from_product', 'to_product', 
                'avg_substitution', 'total_substitution', 'occurrence_rate'
            ]]
            substitution_df.to_excel(writer, sheet_name='替代对分析', index=False, float_format='%.2f')
            
            # 4. 统计摘要
            summary_data = {
                '指标': ['最低总成本', '最高总成本', '平均总成本', '总成本标准差'],
                '数值': [
                    cost_df['total_cost'].min(),
                    cost_df['total_cost'].max(), 
                    cost_df['total_cost'].mean(),
                    cost_df['total_cost'].std()
                ]
            }
            summary_df = pd.DataFrame(summary_data)
            summary_df.to_excel(writer, sheet_name='统计摘要', index=False)
            
            # 5. 趋势分析
            trend_analysis = cost_df[['total_cost']].copy()
            trend_analysis['变化率(%)'] = trend_analysis['total_cost'].pct_change() * 100
            trend_analysis.to_excel(writer, sheet_name='趋势分析')
        
        print(f"\n{'='*60}")
        print(f"所有结果已保存到: {excel_filename}")
        print(f"{'='*60}")
        
        # 打印汇总信息
        print(f"\nExcel文件包含以下工作表:")
        print(f"1. 成本分析 - 各数据集的成本分解")
        print(f"2. 缺货分析 - 各产品的缺货和替代统计") 
        print(f"3. 替代对分析 - 具体替代关系的详细统计")
        print(f"4. 统计摘要 - 总体统计信息")
        print(f"5. 趋势分析 - 成本变化趋势")
        
        # 打印成本汇总表格
        print(f"\n成本分析汇总表:")
        print(cost_df.round(2))
        
        # 打印总体缺货统计
        total_initial_shortage = shortage_df.groupby('data_number')['avg_initial_shortage'].sum()
        total_final_shortage = shortage_df.groupby('data_number')['avg_final_shortage'].sum()
        total_compensated = shortage_df.groupby('data_number')['avg_compensated'].sum()
        
        print(f"\n总体缺货分析:")
        for num in data_numbers:
            if num in total_initial_shortage:
                initial = total_initial_shortage[num]
                final = total_final_shortage[num]
                compensated = total_compensated[num]
                compensation_rate = (compensated / initial * 100) if initial > 0 else 0
                reduction_rate = ((initial - final) / initial * 100) if initial > 0 else 0
                
                print(f"数据 {num}: 初始缺货={initial:.2f}, 最终缺货={final:.2f}, "
                      f"替代补偿={compensated:.2f}, 补偿率={compensation_rate:.1f}%, "
                      f"缺货减少率={reduction_rate:.1f}%")
            
    else:
        print("没有成功处理任何数据文件。")